import { hash } from "bcryptjs";
import { PrismaClient, ReportCategory, ReportStatus, ReportVisibility, Role } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  await prisma.report.deleteMany();
  await prisma.user.deleteMany();

  const adminPassword = await hash("Admin1234!", 10);
  const analystPassword = await hash("Analyst1234!", 10);

  const admin = await prisma.user.create({
    data: {
      name: "Amira Chen",
      email: "admin@reporting.local",
      passwordHash: adminPassword,
      role: Role.ADMIN
    }
  });

  const analyst = await prisma.user.create({
    data: {
      name: "Nora Bennett",
      email: "analyst@reporting.local",
      passwordHash: analystPassword,
      role: Role.ANALYST
    }
  });

  await prisma.report.createMany({
    data: [
      {
        title: "Q1 Revenue Pulse",
        description: "Tracks quarterly revenue by region, including channel contribution and monthly trend lines for the executive team.",
        category: ReportCategory.REVENUE,
        status: ReportStatus.PUBLISHED,
        visibility: ReportVisibility.PUBLIC,
        periodLabel: "Q1 2026",
        metricValue: 2450000,
        metricDelta: 12.4,
        chartData: JSON.stringify([
          { label: "Jan", value: 710000 },
          { label: "Feb", value: 790000 },
          { label: "Mar", value: 950000 }
        ]),
        authorId: admin.id
      },
      {
        title: "Customer Retention Watch",
        description: "Measures retained accounts, churn pressure, and renewal performance for the customer success organization.",
        category: ReportCategory.CUSTOMER,
        status: ReportStatus.PUBLISHED,
        visibility: ReportVisibility.TEAM,
        periodLabel: "March 2026",
        metricValue: 91,
        metricDelta: 2.7,
        chartData: JSON.stringify([
          { label: "Enterprise", value: 96 },
          { label: "Mid-market", value: 90 },
          { label: "SMB", value: 84 }
        ]),
        authorId: analyst.id
      },
      {
        title: "Pipeline Efficiency Snapshot",
        description: "Shows lead velocity, conversion rate, and campaign influence across marketing and sales operations.",
        category: ReportCategory.MARKETING,
        status: ReportStatus.DRAFT,
        visibility: ReportVisibility.PRIVATE,
        periodLabel: "March 2026",
        metricValue: 34,
        metricDelta: -4.2,
        chartData: JSON.stringify([
          { label: "MQL", value: 1200 },
          { label: "SQL", value: 520 },
          { label: "Closed", value: 115 }
        ]),
        authorId: analyst.id
      }
    ]
  });
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (error) => {
    console.error(error);
    await prisma.$disconnect();
    process.exit(1);
  });
