export type Role = "ADMIN" | "SUPERUSER" | "BASIC_USER";
export type Severity = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
export type ActionStatus = "OPEN" | "IN_PROGRESS" | "CLOSED";
export type WorkflowStage = "REGISTERED" | "UNDER_REVIEW" | "MANAGEMENT_REVIEW" | "CLOSED";
export type ObservationType = "SAFE_ACT" | "UNSAFE_ACT" | "UNSAFE_CONDITION";
export type IncidentType =
  | "FIRST_AID_CASE"
  | "MEDICAL_TREATMENT_CASE"
  | "LOST_TIME_INJURY"
  | "PROPERTY_DAMAGE"
  | "NEAR_MISS"
  | "NON_CONFORMANCE";
export type AuditType = "INTERNAL_AUDIT" | "EXTERNAL_AUDIT" | "COMPLIANCE_INSPECTION" | "BEHAVIORAL_AUDIT";

export type SessionUser = {
  id: string;
  name: string;
  email: string;
  role: Role;
};

export type ReportCategory =
  | "OBSERVATION"
  | "CONVERSATION"
  | "ACCIDENT"
  | "NON_CONFORMANCE"
  | "TRAINING"
  | "HSE_REPORT"
  | "ENVIRONMENT_AUDIT"
  | "SAFETY_INSPECTION";
export type ReportStatus = "DRAFT" | "PUBLISHED" | "ARCHIVED";
export type ReportVisibility = "PRIVATE" | "TEAM" | "PUBLIC";

export type ChartPoint = {
  label: string;
  value: number;
};

export type ActionItem = {
  title: string;
  owner: string;
  dueDate: string;
  status: ActionStatus;
};

export type UserRecord = SessionUser & {
  passwordHash: string;
  createdAt: string;
  updatedAt: string;
};

export type ThemeSettings = {
  brandName: string;
  productLabel: string;
  platformLogoUrl: string;
  companyName: string;
  companyLogoUrl: string;
  dashboardTitle: string;
  dashboardDescription: string;
  loginTitle: string;
  loginDescription: string;
  primaryColor: string;
  accentColor: string;
  sidebarColor: string;
  surfaceTint: string;
};

export type PlatformSettings = ThemeSettings & {
  bodyMapTitle: string;
  bodyMapDescription: string;
};

export type ReportRecord = {
  id: string;
  caseNumber: string;
  title: string;
  description: string;
  category: ReportCategory;
  workflowStage: WorkflowStage;
  focalPerson: string;
  responsibleUnit: string;
  incidentType: IncidentType;
  observationType: ObservationType;
  auditType: AuditType;
  managementRemarks: string;
  consequenceSummary: string;
  investigationStartDate: string;
  resolutionDate: string;
  seriousFinding: boolean;
  hasNonConformance: boolean;
  site: string;
  department: string;
  reportedBy: string;
  incidentDate: string;
  severity: Severity;
  potentialSeverity: Severity;
  bodyPart: string;
  riskType: string;
  process: string;
  system: string;
  equipment: string;
  deviation: string;
  cause: string;
  personsInvolved: number;
  lostTimeDays: number;
  trainingHours: number;
  auditScore: number;
  correctiveActionSummary: string;
  rootCause: string;
  status: ReportStatus;
  visibility: ReportVisibility;
  periodLabel: string;
  metricValue: number;
  metricDelta: number;
  chartData: ChartPoint[];
  actions: ActionItem[];
  authorId: string;
  createdAt: string;
  updatedAt: string;
};
