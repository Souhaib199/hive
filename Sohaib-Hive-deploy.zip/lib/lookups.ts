export const CATEGORY_OPTIONS = [
  "OBSERVATION",
  "CONVERSATION",
  "ACCIDENT",
  "NON_CONFORMANCE",
  "TRAINING",
  "HSE_REPORT",
  "ENVIRONMENT_AUDIT",
  "SAFETY_INSPECTION"
] as const;

export const SEVERITY_OPTIONS = ["LOW", "MEDIUM", "HIGH", "CRITICAL"] as const;
export const STATUS_OPTIONS = ["DRAFT", "PUBLISHED", "ARCHIVED"] as const;
export const VISIBILITY_OPTIONS = ["PRIVATE", "TEAM", "PUBLIC"] as const;
export const WORKFLOW_STAGE_OPTIONS = ["REGISTERED", "UNDER_REVIEW", "MANAGEMENT_REVIEW", "CLOSED"] as const;
export const OBSERVATION_TYPE_OPTIONS = ["SAFE_ACT", "UNSAFE_ACT", "UNSAFE_CONDITION"] as const;
export const INCIDENT_TYPE_OPTIONS = [
  "FIRST_AID_CASE",
  "MEDICAL_TREATMENT_CASE",
  "LOST_TIME_INJURY",
  "PROPERTY_DAMAGE",
  "NEAR_MISS",
  "NON_CONFORMANCE"
] as const;
export const AUDIT_TYPE_OPTIONS = [
  "INTERNAL_AUDIT",
  "EXTERNAL_AUDIT",
  "COMPLIANCE_INSPECTION",
  "BEHAVIORAL_AUDIT"
] as const;

export const SITE_OPTIONS = [
  "Main Site",
  "Warehouse A",
  "Process Plant",
  "Maintenance Yard",
  "Utilities Block",
  "Office Complex"
] as const;

export const DEPARTMENT_OPTIONS = [
  "Operations",
  "Logistics",
  "Maintenance",
  "Utilities",
  "Projects",
  "Administration"
] as const;

export const BODY_PART_OPTIONS = [
  "Head",
  "Eyes",
  "Hands",
  "Torso",
  "Back",
  "Legs",
  "Feet",
  "General"
] as const;

export const RISK_TYPE_OPTIONS = [
  "Line of Fire",
  "Slip / Trip / Fall",
  "Manual Handling",
  "PPE Compliance",
  "Vehicle Movement",
  "Dropped Objects",
  "Environmental Spill",
  "Permit to Work"
] as const;

export const PROCESS_OPTIONS = [
  "Loading and Unloading",
  "Warehouse Handling",
  "Lifting Operation",
  "Confined Space Entry",
  "Maintenance Intervention",
  "Waste Handling"
] as const;

export const SYSTEM_OPTIONS = [
  "Traffic Management",
  "Permit to Work",
  "Isolation and LOTO",
  "Waste Segregation",
  "Emergency Response",
  "Training Compliance"
] as const;

export const EQUIPMENT_OPTIONS = [
  "Forklift",
  "Scaffold",
  "Hand Tools",
  "Spill Kit",
  "Pressure Vessel",
  "Fire Extinguisher"
] as const;

export const CAUSE_OPTIONS = [
  "Procedure not followed",
  "Poor housekeeping",
  "Inadequate supervision",
  "Weak traffic segregation",
  "Insufficient training",
  "Equipment defect"
] as const;

export const DEVIATION_OPTIONS = [
  "Unsafe act",
  "Unsafe condition",
  "Barrier failure",
  "PPE not worn",
  "Poor ergonomics",
  "Environmental non-conformance"
] as const;
