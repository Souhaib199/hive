import { z } from "zod";

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8)
});

export const reportSchema = z.object({
  title: z.string().min(3).max(120),
  description: z.string().min(20).max(1200),
  category: z.enum([
    "OBSERVATION",
    "CONVERSATION",
    "ACCIDENT",
    "NON_CONFORMANCE",
    "TRAINING",
    "HSE_REPORT",
    "ENVIRONMENT_AUDIT",
    "SAFETY_INSPECTION"
  ]),
  caseNumber: z.string().min(3).max(40).optional(),
  workflowStage: z.enum(["REGISTERED", "UNDER_REVIEW", "MANAGEMENT_REVIEW", "CLOSED"]).default("REGISTERED"),
  focalPerson: z.string().min(2).max(80),
  responsibleUnit: z.string().min(2).max(80),
  incidentType: z.enum([
    "FIRST_AID_CASE",
    "MEDICAL_TREATMENT_CASE",
    "LOST_TIME_INJURY",
    "PROPERTY_DAMAGE",
    "NEAR_MISS",
    "NON_CONFORMANCE"
  ]),
  observationType: z.enum(["SAFE_ACT", "UNSAFE_ACT", "UNSAFE_CONDITION"]),
  auditType: z.enum(["INTERNAL_AUDIT", "EXTERNAL_AUDIT", "COMPLIANCE_INSPECTION", "BEHAVIORAL_AUDIT"]),
  managementRemarks: z.string().min(2).max(500),
  consequenceSummary: z.string().min(2).max(500),
  investigationStartDate: z.string().min(4).max(30),
  resolutionDate: z.string().min(4).max(30),
  seriousFinding: z.coerce.boolean(),
  hasNonConformance: z.coerce.boolean(),
  site: z.string().min(2).max(80),
  department: z.string().min(2).max(80),
  reportedBy: z.string().min(2).max(80),
  incidentDate: z.string().min(4).max(30),
  severity: z.enum(["LOW", "MEDIUM", "HIGH", "CRITICAL"]),
  potentialSeverity: z.enum(["LOW", "MEDIUM", "HIGH", "CRITICAL"]),
  bodyPart: z.string().min(2).max(80),
  riskType: z.string().min(2).max(80),
  process: z.string().min(2).max(80),
  system: z.string().min(2).max(80),
  equipment: z.string().min(2).max(80),
  deviation: z.string().min(2).max(80),
  cause: z.string().min(2).max(120),
  personsInvolved: z.coerce.number().int().nonnegative(),
  lostTimeDays: z.coerce.number().int().nonnegative(),
  trainingHours: z.coerce.number().nonnegative(),
  auditScore: z.coerce.number().min(0).max(100),
  correctiveActionSummary: z.string().min(5).max(400),
  rootCause: z.string().min(5).max(400),
  status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]).default("DRAFT"),
  visibility: z.enum(["PRIVATE", "TEAM", "PUBLIC"]).default("TEAM"),
  periodLabel: z.string().min(2).max(40),
  metricValue: z.coerce.number().nonnegative(),
  metricDelta: z.coerce.number(),
  chartData: z.array(
    z.object({
      label: z.string(),
      value: z.number()
    })
  ),
  actions: z.array(
    z.object({
      title: z.string().min(2).max(120),
      owner: z.string().min(2).max(80),
      dueDate: z.string().min(4).max(30),
      status: z.enum(["OPEN", "IN_PROGRESS", "CLOSED"])
    })
  )
});
