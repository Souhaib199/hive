import { promises as fs } from "fs";
import path from "path";
import { randomUUID } from "crypto";
import { hash } from "bcryptjs";

import { defaultSettings } from "@/lib/settings";
import type { PlatformSettings, ReportRecord, Role, UserRecord } from "@/lib/types";

type StoreShape = {
  settings: PlatformSettings;
  users: UserRecord[];
  reports: ReportRecord[];
};

const storePath = path.join(process.cwd(), "data", "store.json");

function normalizeRole(role?: string): Role {
  if (role === "ADMIN" || role === "SUPERUSER" || role === "BASIC_USER") {
    return role;
  }
  if (role === "ANALYST") {
    return "SUPERUSER";
  }
  return "BASIC_USER";
}

function normalizeUser(user: Partial<UserRecord>): UserRecord {
  const now = new Date().toISOString();
  return {
    id: user.id ?? randomUUID(),
    name: user.name ?? "User",
    email: user.email ?? `user-${Math.random().toString(36).slice(2)}@reporting.local`,
    role: normalizeRole(user.role),
    passwordHash: user.passwordHash ?? "",
    createdAt: user.createdAt ?? now,
    updatedAt: user.updatedAt ?? now
  };
}

function normalizeReport(report: Partial<ReportRecord>): ReportRecord {
  return {
    id: report.id ?? randomUUID(),
    caseNumber: report.caseNumber ?? `HSE-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9000) + 1000)}`,
    title: report.title ?? "Untitled HSE Entry",
    description: report.description ?? "No description provided.",
    category: report.category ?? "OBSERVATION",
    workflowStage: report.workflowStage ?? "REGISTERED",
    focalPerson: report.focalPerson ?? report.reportedBy ?? "HSE Focal Point",
    responsibleUnit: report.responsibleUnit ?? report.department ?? "Operations",
    incidentType: report.incidentType ?? "NEAR_MISS",
    observationType: report.observationType ?? "UNSAFE_CONDITION",
    auditType: report.auditType ?? "INTERNAL_AUDIT",
    managementRemarks: report.managementRemarks ?? "Awaiting management review.",
    consequenceSummary: report.consequenceSummary ?? "No significant consequence recorded.",
    investigationStartDate: report.investigationStartDate ?? report.incidentDate ?? "2026-04-01",
    resolutionDate: report.resolutionDate ?? report.incidentDate ?? "2026-04-07",
    seriousFinding: report.seriousFinding ?? false,
    hasNonConformance: report.hasNonConformance ?? false,
    site: report.site ?? "Main Site",
    department: report.department ?? "Operations",
    reportedBy: report.reportedBy ?? "Supervisor",
    incidentDate: report.incidentDate ?? "2026-04-01",
    severity: report.severity ?? "LOW",
    potentialSeverity: report.potentialSeverity ?? "MEDIUM",
    bodyPart: report.bodyPart ?? "General",
    riskType: report.riskType ?? "General Risk",
    process: report.process ?? "Warehouse Handling",
    system: report.system ?? "Traffic Management",
    equipment: report.equipment ?? "Hand Tools",
    deviation: report.deviation ?? "Unsafe condition",
    cause: report.cause ?? "Procedure not followed",
    personsInvolved: report.personsInvolved ?? 0,
    lostTimeDays: report.lostTimeDays ?? 0,
    trainingHours: report.trainingHours ?? 0,
    auditScore: report.auditScore ?? 0,
    correctiveActionSummary: report.correctiveActionSummary ?? "No corrective action summary yet.",
    rootCause: report.rootCause ?? "Root cause not yet recorded.",
    status: report.status ?? "DRAFT",
    visibility: report.visibility ?? "TEAM",
    periodLabel: report.periodLabel ?? "April 2026",
    metricValue: report.metricValue ?? 0,
    metricDelta: report.metricDelta ?? 0,
    chartData: report.chartData ?? [],
    actions: report.actions ?? [],
    authorId: report.authorId ?? "",
    createdAt: report.createdAt ?? new Date().toISOString(),
    updatedAt: report.updatedAt ?? new Date().toISOString()
  };
}

async function createSeedData(): Promise<StoreShape> {
  const adminPassword = await hash("Admin1234!", 10);
  const superPassword = await hash("Super1234!", 10);
  const basicPassword = await hash("Basic1234!", 10);
  const now = new Date().toISOString();

  const users: UserRecord[] = [
    {
      id: randomUUID(),
      name: "Sohaib Admin",
      email: "admin@reporting.local",
      passwordHash: adminPassword,
      role: "ADMIN",
      createdAt: now,
      updatedAt: now
    },
    {
      id: randomUUID(),
      name: "HSE Supervisor",
      email: "super@reporting.local",
      passwordHash: superPassword,
      role: "SUPERUSER",
      createdAt: now,
      updatedAt: now
    },
    {
      id: randomUUID(),
      name: "Field User",
      email: "basic@reporting.local",
      passwordHash: basicPassword,
      role: "BASIC_USER",
      createdAt: now,
      updatedAt: now
    }
  ];

  const reports: ReportRecord[] = [
    {
      id: randomUUID(),
      caseNumber: "HSE-2026-0001",
      title: "Forklift Near-Miss Observation",
      description:
        "A near-miss was reported in the warehouse after a forklift reversed into a pedestrian zone without a spotter. Immediate controls and coaching were applied.",
      category: "OBSERVATION",
      workflowStage: "UNDER_REVIEW",
      focalPerson: "Warehouse HSE Lead",
      responsibleUnit: "Logistics",
      incidentType: "NEAR_MISS",
      observationType: "UNSAFE_CONDITION",
      auditType: "INTERNAL_AUDIT",
      managementRemarks: "Review traffic segregation and close all corrective actions before next shift.",
      consequenceSummary: "Potential hand injury and pedestrian collision exposure.",
      investigationStartDate: "2026-04-01",
      resolutionDate: "2026-04-08",
      seriousFinding: true,
      hasNonConformance: false,
      site: "Warehouse A",
      department: "Logistics",
      reportedBy: "Shift Supervisor",
      incidentDate: "2026-04-01",
      severity: "MEDIUM",
      potentialSeverity: "HIGH",
      bodyPart: "Hands",
      riskType: "Line of Fire",
      process: "Warehouse Handling",
      system: "Traffic Management",
      equipment: "Forklift",
      deviation: "Barrier failure",
      cause: "Weak traffic segregation",
      personsInvolved: 1,
      lostTimeDays: 0,
      trainingHours: 0,
      auditScore: 88,
      correctiveActionSummary: "Repainted the pedestrian lane and enforced spotter use during reversing.",
      rootCause: "Restricted visibility and weak traffic segregation controls.",
      status: "PUBLISHED",
      visibility: "PUBLIC",
      periodLabel: "April 2026",
      metricValue: 18,
      metricDelta: -12.4,
      chartData: [
        { label: "Week 1", value: 8 },
        { label: "Week 2", value: 6 },
        { label: "Week 3", value: 4 }
      ],
      actions: [
        {
          title: "Install forklift reversing mirrors",
          owner: "Maintenance Lead",
          dueDate: "2026-04-08",
          status: "IN_PROGRESS"
        },
        {
          title: "Refresh spotter briefing with operators",
          owner: "HSE Manager",
          dueDate: "2026-04-03",
          status: "OPEN"
        }
      ],
      authorId: users[0].id,
      createdAt: now,
      updatedAt: now
    },
    {
      id: randomUUID(),
      caseNumber: "HSE-2026-0002",
      title: "Supervisor Safety Conversation Drive",
      description:
        "Supervisors completed structured field conversations on PPE discipline, line-of-fire hazards, and housekeeping expectations.",
      category: "CONVERSATION",
      workflowStage: "MANAGEMENT_REVIEW",
      focalPerson: "Area HSE Superintendent",
      responsibleUnit: "Operations",
      incidentType: "FIRST_AID_CASE",
      observationType: "SAFE_ACT",
      auditType: "BEHAVIORAL_AUDIT",
      managementRemarks: "Expand field conversations to the night shift and track leading indicator quality.",
      consequenceSummary: "Improved PPE discipline and stronger field engagement.",
      investigationStartDate: "2026-03-28",
      resolutionDate: "2026-04-05",
      seriousFinding: false,
      hasNonConformance: false,
      site: "Process Plant",
      department: "Operations",
      reportedBy: "Area Superintendent",
      incidentDate: "2026-03-28",
      severity: "LOW",
      potentialSeverity: "MEDIUM",
      bodyPart: "Torso",
      riskType: "PPE Compliance",
      process: "Loading and Unloading",
      system: "Training Compliance",
      equipment: "Hand Tools",
      deviation: "Unsafe act",
      cause: "Inadequate supervision",
      personsInvolved: 14,
      lostTimeDays: 0,
      trainingHours: 6,
      auditScore: 92,
      correctiveActionSummary: "Issued toolbox talks and introduced weekly field leadership checks.",
      rootCause: "Inconsistent supervisor presence in the field during peak work hours.",
      status: "PUBLISHED",
      visibility: "TEAM",
      periodLabel: "March 2026",
      metricValue: 46,
      metricDelta: 14.2,
      chartData: [
        { label: "Area A", value: 18 },
        { label: "Area B", value: 11 },
        { label: "Area C", value: 17 }
      ],
      actions: [
        {
          title: "Complete weekly supervisor field coaching plan",
          owner: "Operations Manager",
          dueDate: "2026-04-05",
          status: "IN_PROGRESS"
        }
      ],
      authorId: users[1].id,
      createdAt: now,
      updatedAt: now
    },
    {
      id: randomUUID(),
      caseNumber: "HSE-2026-0003",
      title: "Environmental Audit Findings",
      description:
        "Routine environmental audit identified spill-control gaps, waste segregation issues, and incomplete chemical labeling in the maintenance yard.",
      category: "ENVIRONMENT_AUDIT",
      workflowStage: "REGISTERED",
      focalPerson: "Environmental Coordinator",
      responsibleUnit: "Utilities",
      incidentType: "NON_CONFORMANCE",
      observationType: "UNSAFE_CONDITION",
      auditType: "COMPLIANCE_INSPECTION",
      managementRemarks: "Escalate the spill-control gap and verify waste-area standards after closure.",
      consequenceSummary: "Potential environmental spill, labeling non-compliance, and waste handling exposure.",
      investigationStartDate: "2026-03-18",
      resolutionDate: "2026-04-12",
      seriousFinding: true,
      hasNonConformance: true,
      site: "Maintenance Yard",
      department: "Utilities",
      reportedBy: "Environmental Officer",
      incidentDate: "2026-03-18",
      severity: "HIGH",
      potentialSeverity: "HIGH",
      bodyPart: "Legs",
      riskType: "Environmental Spill",
      process: "Waste Handling",
      system: "Waste Segregation",
      equipment: "Spill Kit",
      deviation: "Environmental non-conformance",
      cause: "Poor housekeeping",
      personsInvolved: 0,
      lostTimeDays: 0,
      trainingHours: 2,
      auditScore: 67,
      correctiveActionSummary: "Restock spill kits, relabel drums, and segregate general and hazardous waste streams.",
      rootCause: "Weak inspection discipline and incomplete housekeeping ownership.",
      status: "DRAFT",
      visibility: "PRIVATE",
      periodLabel: "March 2026",
      metricValue: 9,
      metricDelta: 22.2,
      chartData: [
        { label: "Spill kits", value: 2 },
        { label: "Labeling", value: 4 },
        { label: "Waste", value: 3 }
      ],
      actions: [
        {
          title: "Replace missing spill response materials",
          owner: "Warehouse Coordinator",
          dueDate: "2026-04-06",
          status: "OPEN"
        },
        {
          title: "Close out waste labeling findings",
          owner: "Utilities Supervisor",
          dueDate: "2026-04-09",
          status: "OPEN"
        }
      ],
      authorId: users[1].id,
      createdAt: now,
      updatedAt: now
    }
  ];

  return { settings: defaultSettings, users, reports };
}

export async function readStore() {
  try {
    const raw = await fs.readFile(storePath, "utf8");
    const parsed = JSON.parse(raw) as StoreShape;
    if (parsed.users.length === 0 && parsed.reports.length === 0) {
      const seed = await createSeedData();
      await writeStore(seed);
      return seed;
    }
    const normalized = {
      settings: {
        ...defaultSettings,
        ...(parsed.settings ?? {})
      },
      users: parsed.users.map((user) => normalizeUser(user)),
      reports: parsed.reports.map((report) => normalizeReport(report))
    };
    await writeStore(normalized);
    return normalized;
  } catch {
    const seed = await createSeedData();
    await writeStore(seed);
    return seed;
  }
}

export async function writeStore(data: StoreShape) {
  await fs.mkdir(path.dirname(storePath), { recursive: true });
  await fs.writeFile(storePath, JSON.stringify(data, null, 2));
}

export async function findUserByEmail(email: string) {
  const store = await readStore();
  return store.users.find((user) => user.email === email) ?? null;
}

export async function getSettings() {
  const store = await readStore();
  return store.settings;
}

export async function updateSettings(settings: Partial<PlatformSettings>) {
  const store = await readStore();
  store.settings = {
    ...store.settings,
    ...settings
  };
  await writeStore(store);
  return store.settings;
}

export async function listUsers() {
  const store = await readStore();
  return store.users;
}

export async function createUser({
  name,
  email,
  role,
  password
}: {
  name: string;
  email: string;
  role: Role;
  password: string;
}) {
  const store = await readStore();
  const existing = store.users.find((user) => user.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    throw new Error("User already exists");
  }

  const now = new Date().toISOString();
  const user: UserRecord = {
    id: randomUUID(),
    name,
    email,
    role,
    passwordHash: await hash(password, 10),
    createdAt: now,
    updatedAt: now
  };

  store.users.push(user);
  await writeStore(store);
  return user;
}

export async function updateUser(
  id: string,
  data: Partial<Pick<UserRecord, "name" | "email" | "role">> & { password?: string }
) {
  const store = await readStore();
  const user = store.users.find((item) => item.id === id);
  if (!user) {
    return null;
  }

  if (data.name) user.name = data.name;
  if (data.email) user.email = data.email;
  if (data.role) user.role = data.role;
  if (data.password) user.passwordHash = await hash(data.password, 10);
  user.updatedAt = new Date().toISOString();
  await writeStore(store);
  return user;
}

export async function deleteUser(id: string) {
  const store = await readStore();
  const nextUsers = store.users.filter((user) => user.id !== id);
  if (nextUsers.length === store.users.length) {
    return false;
  }
  store.users = nextUsers;
  await writeStore(store);
  return true;
}

export async function listReports() {
  const store = await readStore();
  return store.reports;
}

export async function findReportById(id: string) {
  const store = await readStore();
  return store.reports.find((report) => report.id === id) ?? null;
}

export async function createReport(
  report: Omit<ReportRecord, "id" | "createdAt" | "updatedAt">
) {
  const store = await readStore();
  const now = new Date().toISOString();
  const sequence = store.reports.length + 1;
  const newReport: ReportRecord = {
    ...report,
    id: randomUUID(),
    caseNumber: report.caseNumber || `HSE-${new Date().getFullYear()}-${String(sequence).padStart(4, "0")}`,
    createdAt: now,
    updatedAt: now
  };

  store.reports.unshift(newReport);
  await writeStore(store);
  return newReport;
}

export async function updateReport(
  id: string,
  report: Omit<ReportRecord, "id" | "createdAt" | "updatedAt">
) {
  const store = await readStore();
  const existing = store.reports.find((item) => item.id === id);
  if (!existing) {
    return null;
  }

  Object.assign(existing, report, { updatedAt: new Date().toISOString() });
  await writeStore(store);
  return existing;
}
