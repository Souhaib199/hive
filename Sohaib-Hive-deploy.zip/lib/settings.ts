import type { PlatformSettings } from "@/lib/types";

export const defaultSettings: PlatformSettings = {
  brandName: "Sohaib Hive",
  productLabel: "HSE Platform",
  platformLogoUrl: "/assets/hse-hive-icon.png",
  companyName: "Client Company",
  companyLogoUrl: "",
  dashboardTitle: "One HSE workspace for observations, conversations, accidents, training, and environmental audits.",
  dashboardDescription:
    "Track field activity, monitor leading and lagging indicators, and give leadership a clear picture of exposure before serious harm happens.",
  loginTitle: "Report HSE observations, conversations, incidents, training, and audits from one place.",
  loginDescription: "Sohaib Hive helps HSE teams capture field data early, spot patterns fast, and prevent serious events.",
  primaryColor: "#2f8f62",
  accentColor: "#87b83d",
  sidebarColor: "#0f261f",
  surfaceTint: "#f4fbf4",
  bodyMapTitle: "Personal injuries by body parts",
  bodyMapDescription:
    "Inspect injury concentration on a detailed front/back body map and review counts by affected body area."
};
