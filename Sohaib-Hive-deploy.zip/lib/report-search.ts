import type { ReportRecord, UserRecord } from "@/lib/types";

export type ReportWithAuthor = ReportRecord & {
  author: UserRecord;
};

export type SearchFilters = {
  query: string;
  status: string;
  severity: string;
  category: string;
  site: string;
  bodyPart: string;
};

export function getSearchFilters(searchParams?: Record<string, string | string[] | undefined>): SearchFilters {
  return {
    query: String(searchParams?.query ?? "").trim().toLowerCase(),
    status: String(searchParams?.status ?? "ALL"),
    severity: String(searchParams?.severity ?? "ALL"),
    category: String(searchParams?.category ?? "ALL"),
    site: String(searchParams?.site ?? "ALL"),
    bodyPart: String(searchParams?.bodyPart ?? "ALL")
  };
}

export function filterReports(reports: ReportWithAuthor[], filters: SearchFilters) {
  return reports.filter((report) => {
    const matchesQuery =
      filters.query.length === 0 ||
      [
        report.title,
        report.description,
        report.site,
        report.department,
        report.bodyPart,
        report.riskType,
        report.author.name
      ]
        .join(" ")
        .toLowerCase()
        .includes(filters.query);

    return (
      matchesQuery &&
      (filters.status === "ALL" || report.status === filters.status) &&
      (filters.severity === "ALL" || report.potentialSeverity === filters.severity) &&
      (filters.category === "ALL" || report.category === filters.category) &&
      (filters.site === "ALL" || report.site === filters.site) &&
      (filters.bodyPart === "ALL" || report.bodyPart === filters.bodyPart)
    );
  });
}

export function getSearchOptions(reports: ReportWithAuthor[]) {
  return {
    sites: Array.from(new Set(reports.map((report) => report.site))).sort(),
    bodyParts: Array.from(new Set(reports.map((report) => report.bodyPart))).sort(),
    categories: Array.from(new Set(reports.map((report) => report.category))).sort()
  };
}
