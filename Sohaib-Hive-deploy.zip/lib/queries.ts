import { listReports, listUsers, findReportById } from "@/lib/store";
import type { UserRecord } from "@/lib/types";

function getFallbackAuthor(authorId: string): UserRecord {
  const now = new Date().toISOString();

  return {
    id: authorId || "deleted-user",
    name: "Removed User",
    email: "removed@reporting.local",
    role: "BASIC_USER",
    passwordHash: "",
    createdAt: now,
    updatedAt: now
  };
}

export async function getDashboardMetrics() {
  const [reports, users] = await Promise.all([listReports(), listUsers()]);
  const reportsWithAuthors = reports
    .map((report) => ({
      ...report,
      author: users.find((user) => user.id === report.authorId) ?? getFallbackAuthor(report.authorId)
    }))
    .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));

  const publishedReports = reportsWithAuthors.filter((report) => report.status === "PUBLISHED");
  const totalValue = reportsWithAuthors.reduce((sum, report) => sum + report.metricValue, 0);
  const observationCount = reportsWithAuthors.filter((report) => report.category === "OBSERVATION").length;
  const conversationCount = reportsWithAuthors.filter((report) => report.category === "CONVERSATION").length;
  const accidentCount = reportsWithAuthors.filter((report) => report.category === "ACCIDENT").length;
  const openActions = reportsWithAuthors.reduce(
    (sum, report) => sum + report.actions.filter((action) => action.status !== "CLOSED").length,
    0
  );
  const overdueActions = reportsWithAuthors.reduce(
    (sum, report) =>
      sum +
      report.actions.filter(
        (action) => action.status !== "CLOSED" && new Date(action.dueDate).getTime() < Date.now()
      ).length,
    0
  );
  const trainingHours = reportsWithAuthors.reduce((sum, report) => sum + report.trainingHours, 0);
  const privateReports = reportsWithAuthors.filter((report) => report.visibility === "PRIVATE").length;

  return {
    totals: {
      reports: reportsWithAuthors.length,
      publishedReports: publishedReports.length,
      privateReports,
      totalValue,
      observationCount,
      conversationCount,
      accidentCount,
      openActions,
      overdueActions,
      trainingHours
    },
    latestReports: reportsWithAuthors.slice(0, 5)
  };
}

export async function getReportById(id: string) {
  const [report, users] = await Promise.all([findReportById(id), listUsers()]);
  if (!report) {
    return null;
  }

  return {
    ...report,
    author: users.find((user) => user.id === report.authorId) ?? getFallbackAuthor(report.authorId)
  };
}

export async function getReportsForList() {
  const [reports, users] = await Promise.all([listReports(), listUsers()]);
  return reports
    .map((report) => ({
      ...report,
      author: users.find((user) => user.id === report.authorId) ?? getFallbackAuthor(report.authorId)
    }))
    .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export async function getAdminOverview() {
  const [users, reports] = await Promise.all([listUsers(), getReportsForList()]);

  return { users, reports };
}
