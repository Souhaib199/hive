# Sohaib Hive

HSE reporting MVP built with Next.js and Tailwind CSS for observations, conversations, accidents, training, and environmental audits.

## What is included

- Role-based authentication using a signed cookie session
- Dashboard homepage with summary metrics and recent report activity
- Report list, report detail, and report creation workflow
- Admin dashboard for team access and report oversight
- Prisma schema and seed data for a local SQLite database
- API routes for auth, reports, metrics, and admin data

## Stack

- Next.js App Router
- TypeScript
- Prisma ORM
- SQLite for local development
- Tailwind CSS
- Zod validation

## Setup

1. Install Node.js 20+ and npm.
2. Install dependencies:

```bash
npm install
```

3. Create `.env`:

```env
DATABASE_URL="file:./prisma/dev.db"
AUTH_SECRET="replace-this-with-a-long-random-string"
```

4. Generate Prisma client and seed the database:

```bash
npm run db:generate
npm run db:migrate -- --name init
npm run db:seed
```

5. Start the app:

```bash
npm run dev
```

## Seeded accounts

- Admin: `admin@reporting.local` / `Admin1234!`
- Analyst: `analyst@reporting.local` / `Analyst1234!`

## Suggested next steps

- Switch Prisma from SQLite to PostgreSQL for production
- Add editable dashboards and saved filters
- Add charts with a library like Recharts or Visx
- Add audit logs, notifications, and export support
