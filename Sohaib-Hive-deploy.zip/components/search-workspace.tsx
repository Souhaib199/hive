import Link from "next/link";
import { Search, SlidersHorizontal } from "lucide-react";

import { ReportTable } from "@/components/report-table";
import type { ReportWithAuthor, SearchFilters } from "@/lib/report-search";

export function SearchWorkspace({
  reports,
  filters,
  options
}: {
  reports: ReportWithAuthor[];
  filters: SearchFilters;
  options: {
    sites: string[];
    bodyParts: string[];
    categories: string[];
  };
}) {
  return (
    <div className="space-y-8">
      <section className="relative overflow-hidden rounded-[38px] border border-white/70 bg-[linear-gradient(135deg,rgba(255,255,255,0.96),rgba(236,245,239,0.92))] p-8 shadow-card">
        <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-[radial-gradient(circle,rgba(47,143,98,0.16),transparent_68%)]" />
        <div className="flex flex-col gap-6 xl:flex-row xl:items-end xl:justify-between">
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <p className="text-sm uppercase tracking-[0.34em] text-teal">Search Engine</p>
              <span className="rounded-full border border-emerald-100 bg-emerald-50 px-3 py-1 text-xs font-semibold uppercase tracking-[0.16em] text-teal">
                Full Search Workspace
              </span>
            </div>
            <h1 className="mt-3 max-w-4xl text-4xl font-semibold leading-tight tracking-[-0.04em] text-ink">
              Search, filter, and isolate HSE intelligence across the whole operation
            </h1>
            <p className="mt-3 max-w-3xl text-sm leading-7 text-slate-500">
              Use the dedicated search workspace to find incidents, observations, injuries, ownership gaps, and site exposure patterns without leaving the register flow.
            </p>
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            <SearchStat label="Results" value={String(reports.length)} />
            <SearchStat
              label="Open Actions"
              value={String(reports.reduce((sum, report) => sum + report.actions.filter((action) => action.status !== "CLOSED").length, 0))}
            />
            <SearchStat
              label="High Potential"
              value={String(reports.filter((report) => report.potentialSeverity === "HIGH" || report.potentialSeverity === "CRITICAL").length)}
            />
          </div>
        </div>
      </section>

      <section className="rounded-[34px] border border-white/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.97),rgba(242,247,243,0.92))] p-6 shadow-card">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.28em] text-slate-500">Filters</p>
            <h2 className="mt-2 text-2xl font-semibold tracking-[-0.03em] text-ink">Precision search controls</h2>
          </div>
          <div className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-600 shadow-sm">
            <SlidersHorizontal className="h-4 w-4 text-emerald-600" />
            Dynamic HSE query builder
          </div>
        </div>

        <form className="mt-6 grid gap-4 xl:grid-cols-6">
          <label className="xl:col-span-2">
            <span className="mb-2 block text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Search</span>
            <div className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm">
              <Search className="h-4 w-4 text-slate-400" />
              <input
                name="query"
                defaultValue={filters.query}
                placeholder="Title, owner, site, body part, risk"
                className="w-full bg-transparent text-sm outline-none placeholder:text-slate-400"
              />
            </div>
          </label>
          <SelectField name="status" label="Status" defaultValue={filters.status} options={["ALL", "DRAFT", "PUBLISHED", "ARCHIVED"]} />
          <SelectField name="severity" label="Severity" defaultValue={filters.severity} options={["ALL", "LOW", "MEDIUM", "HIGH", "CRITICAL"]} />
          <SelectField name="category" label="Category" defaultValue={filters.category} options={["ALL", ...options.categories]} />
          <SelectField name="site" label="Site" defaultValue={filters.site} options={["ALL", ...options.sites]} />
          <SelectField name="bodyPart" label="Body Part" defaultValue={filters.bodyPart} options={["ALL", ...options.bodyParts]} />
          <div className="xl:col-span-6 flex flex-wrap gap-3">
            <button type="submit" className="rounded-2xl bg-clay px-5 py-3 text-sm font-semibold text-white shadow-[0_16px_34px_rgba(47,143,98,0.24)]">
              Run Search
            </button>
            <Link href="/search" className="rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700">
              Reset
            </Link>
          </div>
        </form>
      </section>

      <ReportTable reports={reports} />
    </div>
  );
}

function SearchStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-[22px] border border-white bg-white/85 px-5 py-4 shadow-sm">
      <p className="text-[11px] uppercase tracking-[0.18em] text-slate-500">{label}</p>
      <p className="mt-2 text-3xl font-semibold tracking-[-0.03em] text-ink">{value}</p>
    </div>
  );
}

function SelectField({
  name,
  label,
  defaultValue,
  options
}: {
  name: string;
  label: string;
  defaultValue: string;
  options: string[];
}) {
  return (
    <label>
      <span className="mb-2 block text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">{label}</span>
      <select name={name} defaultValue={defaultValue} className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm shadow-sm">
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </label>
  );
}
