import { ArrowDownRight, ArrowUpRight } from "lucide-react";

import { cn } from "@/lib/utils";

export function MetricCard({
  title,
  value,
  delta,
  caption
}: {
  title: string;
  value: string;
  delta?: number;
  caption: string;
}) {
  const positive = (delta ?? 0) >= 0;

  return (
    <article className="group relative overflow-hidden rounded-[30px] border border-white/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.97),rgba(241,247,243,0.93))] p-6 shadow-card backdrop-blur">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white to-transparent opacity-80" />
      <div className="absolute -right-10 -top-10 h-28 w-28 rounded-full bg-[radial-gradient(circle,rgba(47,143,98,0.24),transparent_70%)] transition duration-500 group-hover:scale-110" />
      <div className="absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r from-[var(--brand-primary)] via-[#59b57b] to-[var(--brand-accent)]" />
      <div className="flex items-center justify-between gap-4">
        <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-slate-500">{title}</p>
        <span className="rounded-full border border-emerald-100 bg-emerald-50/80 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-emerald-700">
          Live
        </span>
      </div>
      <div className="mt-6 flex items-end justify-between gap-4">
        <div>
          <h3 className="text-5xl font-semibold tracking-[-0.04em] text-ink">{value}</h3>
          <p className="mt-3 max-w-[18rem] text-sm leading-6 text-slate-500">{caption}</p>
        </div>
        {typeof delta === "number" ? (
          <span
            className={cn(
              "inline-flex items-center gap-1 rounded-full border px-3 py-1.5 text-sm font-semibold shadow-sm",
              positive
                ? "border-emerald-100 bg-emerald-50 text-emerald-600"
                : "border-rose-100 bg-rose-50 text-rose-600"
            )}
          >
            {positive ? <ArrowUpRight className="h-4 w-4" /> : <ArrowDownRight className="h-4 w-4" />}
            {Math.abs(delta)}%
          </span>
        ) : null}
      </div>
    </article>
  );
}
