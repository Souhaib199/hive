import Link from "next/link";
import { BarChart3, FileSearch, FileText, LayoutDashboard, Shield } from "lucide-react";

import { Logo } from "@/components/logo";
import { LogoutButton } from "@/components/logout-button";
import type { SessionUser } from "@/lib/types";

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/reports", label: "HSE Reports", icon: FileText },
  { href: "/search", label: "Search Engine", icon: FileSearch },
  { href: "/reports/new", label: "New Entry", icon: BarChart3 }
];

export function Sidebar({ user }: { user: SessionUser }) {
  return (
    <aside
      className="flex min-h-screen w-full max-w-80 flex-col justify-between border-r border-[#214437] p-6 text-white"
      style={{ backgroundColor: "var(--brand-sidebar)" }}
    >
      <div className="space-y-10">
        <Logo />
        <div className="rounded-[28px] border border-white/10 bg-white/5 p-4">
          <p className="text-xs uppercase tracking-[0.28em] text-[#95c6a8]">Platform</p>
          <p className="mt-2 text-2xl font-semibold">Operational HSE Intelligence</p>
          <p className="mt-2 text-sm leading-6 text-slate-300">
            Investigations, actions, audits, and field observations in one professional workspace.
          </p>
        </div>
        <nav className="space-y-2">
          <p className="px-3 text-xs uppercase tracking-[0.28em] text-[#95c6a8]">Navigation</p>
          {navItems.map((item) => {
            const Icon = item.icon;

            return (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center gap-3 rounded-2xl border border-transparent px-4 py-3 text-sm font-medium text-slate-200 transition hover:border-white/10 hover:bg-white/10 hover:text-white"
              >
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/8">
                  <Icon className="h-4 w-4" />
                </span>
                {item.label}
              </Link>
            );
          })}

          {user.role === "ADMIN" ? (
            <Link
              href="/admin"
              className="flex items-center gap-3 rounded-2xl border border-transparent px-4 py-3 text-sm font-medium text-slate-200 transition hover:border-white/10 hover:bg-white/10 hover:text-white"
            >
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/8">
                <Shield className="h-4 w-4" />
              </span>
              Admin
            </Link>
          ) : null}
        </nav>
      </div>

      <div className="space-y-4 rounded-[28px] border border-white/10 bg-white/5 p-4">
        <div>
          <p className="text-xs uppercase tracking-[0.28em] text-[#95c6a8]">Signed in</p>
          <p className="mt-2 font-semibold text-white">{user.name}</p>
          <p className="text-sm text-slate-300">{user.email}</p>
          <p className="mt-1 text-xs font-medium text-[#95c6a8]">{user.role}</p>
        </div>
        <LogoutButton />
      </div>
    </aside>
  );
}
