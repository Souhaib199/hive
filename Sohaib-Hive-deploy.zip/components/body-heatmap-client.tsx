"use client";

import { Expand, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";

type BodyPartDatum = {
  id: string;
  count: number;
  classes: string[];
};

type BodyHeatmapClientProps = {
  frontMarkup: string;
  backMarkup: string;
  data: BodyPartDatum[];
  title: string;
  description: string;
};

export function BodyHeatmapClient({
  frontMarkup,
  backMarkup,
  data,
  title,
  description
}: BodyHeatmapClientProps) {
  const router = useRouter();
  const [activePart, setActivePart] = useState<string | null>(null);
  const [tooltip, setTooltip] = useState<{ x: number; y: number; text: string } | null>(null);
  const [fullscreen, setFullscreen] = useState(false);

  const palette = useMemo(() => {
    const maxCount = Math.max(...data.map((item) => item.count), 1);

    return Object.fromEntries(
      data.map((item) => {
        const strength = item.count / maxCount;
        const fill = strength > 0.75 ? "#1f7a4d" : strength > 0.45 ? "#5cb67c" : "#d6f0db";
        return [item.id, fill];
      })
    );
  }, [data]);

  const activeCount = activePart ? data.find((item) => item.id === activePart)?.count ?? 0 : 0;

  return (
    <>
      <section className="overflow-hidden rounded-[36px] border border-white/80 bg-white/94 shadow-card backdrop-blur">
        <div className="border-b border-slate-100 bg-[linear-gradient(180deg,rgba(255,255,255,0.88),rgba(244,250,245,0.92))] px-6 py-6 lg:px-8">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-slate-500">Body-Part Analysis</p>
              <h2 className="mt-2 text-3xl font-semibold tracking-tight text-ink">{title}</h2>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-500">{description}</p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <div className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-600 shadow-sm">
                {activePart ? <span><b className="text-ink">{activePart}</b>: {activeCount} reported injuries</span> : <span>Move over the body map to inspect injuries.</span>}
              </div>
              <button
                type="button"
                onClick={() => setFullscreen(true)}
                className="inline-flex items-center gap-2 rounded-2xl bg-ink px-4 py-3 text-sm font-semibold text-white"
              >
                <Expand className="h-4 w-4" />
                Full Screen
              </button>
            </div>
          </div>
        </div>

        <div className="px-6 py-6 lg:px-8">
          <div className="rounded-[32px] border border-slate-100 bg-[linear-gradient(180deg,#f9fcf9_0%,#eef6ef_100%)] p-6 shadow-sm">
            <div className="grid gap-6 xl:grid-cols-2">
              <BodySvgPane
                title="Front"
                markup={frontMarkup}
                data={data}
                palette={palette}
                activePart={activePart}
                setActivePart={setActivePart}
                setTooltip={setTooltip}
                onSelect={(part) => router.push(`/reports?bodyPart=${encodeURIComponent(part)}`)}
                tooltip={tooltip}
                large
              />
              <BodySvgPane
                title="Back"
                markup={backMarkup}
                data={data}
                palette={palette}
                activePart={activePart}
                setActivePart={setActivePart}
                setTooltip={setTooltip}
                onSelect={(part) => router.push(`/reports?bodyPart=${encodeURIComponent(part)}`)}
                tooltip={tooltip}
                large
              />
            </div>
          </div>
        </div>
      </section>

      {fullscreen ? (
        <div className="fixed inset-0 z-50 bg-[rgba(9,20,16,0.92)] p-4 backdrop-blur sm:p-6">
          <div className="mx-auto flex h-full max-w-[1700px] flex-col rounded-[32px] border border-white/10 bg-[linear-gradient(180deg,#10271f,#17382d)] shadow-2xl">
            <div className="flex items-center justify-between gap-4 border-b border-white/10 px-6 py-5 text-white">
              <div>
                <p className="text-xs uppercase tracking-[0.24em] text-emerald-200">Full Screen Body View</p>
                <h3 className="mt-2 text-2xl font-semibold">{title}</h3>
              </div>
              <button
                type="button"
                onClick={() => setFullscreen(false)}
                className="inline-flex items-center gap-2 rounded-2xl bg-white/10 px-4 py-3 text-sm font-semibold text-white"
              >
                <X className="h-4 w-4" />
                Close
              </button>
            </div>

            <div className="min-h-0 flex-1 p-6">
              <div className="rounded-[30px] border border-white/10 bg-white/5 p-5">
                <div className="grid gap-6 xl:grid-cols-2">
                  <BodySvgPane
                    title="Front"
                    markup={frontMarkup}
                    data={data}
                    palette={palette}
                    activePart={activePart}
                    setActivePart={setActivePart}
                    setTooltip={setTooltip}
                    onSelect={(part) => {
                      setFullscreen(false);
                      router.push(`/reports?bodyPart=${encodeURIComponent(part)}`);
                    }}
                    tooltip={tooltip}
                    dark
                    large
                  />
                  <BodySvgPane
                    title="Back"
                    markup={backMarkup}
                    data={data}
                    palette={palette}
                    activePart={activePart}
                    setActivePart={setActivePart}
                    setTooltip={setTooltip}
                    onSelect={(part) => {
                      setFullscreen(false);
                      router.push(`/reports?bodyPart=${encodeURIComponent(part)}`);
                    }}
                    tooltip={tooltip}
                    dark
                    large
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}

function BodySvgPane({
  title,
  markup,
  data,
  palette,
  activePart,
  setActivePart,
  setTooltip,
  onSelect,
  tooltip,
  dark = false,
  large = false
}: {
  title: string;
  markup: string;
  data: BodyPartDatum[];
  palette: Record<string, string>;
  activePart: string | null;
  setActivePart: (part: string | null) => void;
  setTooltip: (value: { x: number; y: number; text: string } | null) => void;
  onSelect: (part: string) => void;
  tooltip: { x: number; y: number; text: string } | null;
  dark?: boolean;
  large?: boolean;
}) {
  const styledMarkup = useMemo(() => {
    let result = markup;

    for (const item of data) {
      const fill = palette[item.id];
      for (const className of item.classes) {
        const regex = new RegExp(`class="([^"]*\\b${className}\\b[^"]*)"`, "g");
        result = result.replace(
          regex,
          `class="$1" data-bp="${item.id}" style="fill:${fill};cursor:pointer;opacity:${activePart === item.id ? "1" : "0.96"};"`
        );
      }
    }

    return result;
  }, [activePart, data, markup, palette]);

  return (
    <div
      className={`relative rounded-[26px] border p-4 ${
        dark ? "border-white/10 bg-white/5" : "border-white/70 bg-white/90"
      }`}
    >
      <div className="mb-4 flex items-center justify-between">
        <p className={`text-xs uppercase tracking-[0.2em] ${dark ? "text-emerald-200" : "text-slate-500"}`}>{title} View</p>
        <span className={`rounded-full px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] ${dark ? "bg-white/10 text-white" : "bg-slate-100 text-slate-600"}`}>
          Interactive
        </span>
      </div>

      {tooltip && activePart ? (
        <div
          className="pointer-events-none absolute z-20 rounded-[20px] border border-white/10 bg-[#10271f] px-4 py-3 text-sm font-semibold text-white shadow-2xl"
          style={{ left: tooltip.x + 18, top: tooltip.y + 18 }}
        >
          {tooltip.text}
        </div>
      ) : null}

      <div
        className={`rounded-[24px] ${large ? "p-6" : "p-4"} [perspective:1600px] [&_.bodypart]:transition-all [&_.bodypart]:duration-150 [&_svg]:mx-auto [&_svg]:h-auto [&_svg]:w-full ${
          dark
            ? "bg-[radial-gradient(circle_at_top,rgba(255,255,255,0.1),rgba(255,255,255,0.03))]"
            : "bg-[radial-gradient(circle_at_top,_rgba(255,255,255,0.96),_rgba(231,241,233,0.94))]"
        }`}
        onMouseMove={(event) => {
          const target = event.target as HTMLElement;
          const bp = target.getAttribute("data-bp");
          if (!bp) {
            setTooltip(null);
            return;
          }

          setActivePart(bp);
          const item = data.find((entry) => entry.id === bp);
          if (item) {
            const rect = (event.currentTarget as HTMLDivElement).getBoundingClientRect();
            setTooltip({
              x: event.clientX - rect.left,
              y: event.clientY - rect.top,
              text: `${item.id}: ${item.count} reported injuries`
            });
          }
        }}
        onMouseLeave={() => {
          setActivePart(null);
          setTooltip(null);
        }}
        onClick={(event) => {
          const target = event.target as HTMLElement;
          const bp = target.getAttribute("data-bp");
          if (bp) {
            onSelect(bp);
          }
        }}
        style={{
          filter: activePart ? "saturate(1.08) drop-shadow(0 14px 20px rgba(22,57,40,0.18))" : "drop-shadow(0 12px 18px rgba(22,57,40,0.10))",
          transform: "rotateX(8deg) rotateY(-4deg)"
        }}
        dangerouslySetInnerHTML={{
          __html: `<svg viewBox="0 0 488 810" fill="none" xmlns="http://www.w3.org/2000/svg">${styledMarkup}</svg>`
        }}
      />
    </div>
  );
}
