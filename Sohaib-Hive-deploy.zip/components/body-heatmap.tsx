import { readFile } from "fs/promises";
import path from "path";

import { listReports } from "@/lib/store";
import { getSettings } from "@/lib/store";
import { BodyHeatmapClient } from "@/components/body-heatmap-client";

const oldBase = path.join(
  process.cwd(),
  "old_source",
  "HSE-Hive src demo and landing page 18_11_24",
  "HSE-Hive-src",
  "resources",
  "views",
  "partials"
);

const bodyPartMap: Record<string, { id: string; classes: string[] }> = {
  Head: { id: "Head", classes: ["head", "scalp", "forehead", "face", "nose", "mouthorteeth", "hair", "ear_r", "ear_l"] },
  Eyes: { id: "Eyes", classes: ["eyes", "lefteye", "righteye"] },
  Hands: { id: "Hands", classes: ["lefthand", "righthand", "fingers", "leftwrist", "rightwrist", "nail"] },
  Torso: { id: "Torso", classes: ["chest", "leftchest", "rightchest", "abdomen", "ribs", "back", "neck"] },
  Back: { id: "Back", classes: ["back", "buttocks", "neck_b"] },
  Legs: { id: "Legs", classes: ["leftthigh", "rightthigh", "leftknee", "rightknee", "leftlowerleg", "rightlowerleg"] },
  Feet: { id: "Feet", classes: ["leftfoot", "rightfoot", "toes", "rightankle", "leftankle"] },
  General: { id: "General", classes: ["skin"] }
};

export async function BodyHeatmap() {
  const [frontMarkup, backMarkup, reports, settings] = await Promise.all([
    readFile(path.join(oldBase, "bodyparts_front.blade.php"), "utf8"),
    readFile(path.join(oldBase, "bodyparts_back.blade.php"), "utf8"),
    listReports(),
    getSettings()
  ]);

  const grouped = new Map<string, { id: string; count: number; classes: string[] }>();

  for (const report of reports) {
    const mapped = bodyPartMap[report.bodyPart] ?? bodyPartMap.General;
    const existing = grouped.get(mapped.id);
    if (existing) {
      existing.count += 1;
    } else {
      grouped.set(mapped.id, { id: mapped.id, count: 1, classes: mapped.classes });
    }
  }

  const data = Array.from(grouped.values()).sort((a, b) => b.count - a.count);

  return (
    <BodyHeatmapClient
      frontMarkup={frontMarkup}
      backMarkup={backMarkup}
      data={data}
      title={settings.bodyMapTitle}
      description={settings.bodyMapDescription}
    />
  );
}
