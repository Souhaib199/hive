"use client";

import { AlertTriangle, BellRing, BrainCircuit, TrendingUp } from "lucide-react";

type Insight = {
  title: string;
  detail: string;
  tone: "high" | "medium" | "low";
};

type NotificationItem = {
  title: string;
  detail: string;
  tone: "high" | "medium" | "low";
};

export function PredictiveInsights({
  insights,
  notifications
}: {
  insights: Insight[];
  notifications: NotificationItem[];
}) {
  return (
    <section className="grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
      <div className="rounded-[32px] border border-white/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.96),rgba(240,246,242,0.92))] p-6 shadow-card">
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.28em] text-slate-500">Predictive Analytics</p>
            <h2 className="mt-2 text-2xl font-semibold tracking-[-0.03em] text-ink">AI-style risk signals</h2>
          </div>
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700">
            <BrainCircuit className="h-5 w-5" />
          </span>
        </div>
        <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-500">
          These signals are inferred from current HSE data patterns in the platform, such as open actions, accident concentration, and high-potential exposure.
        </p>

        <div className="mt-6 grid gap-4">
          {insights.map((insight) => (
            <div key={insight.title} className="rounded-[24px] border border-white bg-white/85 p-5 shadow-sm">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="font-semibold text-ink">{insight.title}</p>
                  <p className="mt-2 text-sm leading-6 text-slate-500">{insight.detail}</p>
                </div>
                <span className={toneClass(insight.tone)}>
                  <TrendingUp className="h-4 w-4" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-[32px] border border-white/10 bg-[linear-gradient(180deg,#10271f,#16362b)] p-6 text-white shadow-card">
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.28em] text-emerald-200">Notifications</p>
            <h2 className="mt-2 text-2xl font-semibold tracking-[-0.03em]">Operational alerts</h2>
          </div>
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 text-white">
            <BellRing className="h-5 w-5" />
          </span>
        </div>
        <div className="mt-6 space-y-4">
          {notifications.map((item) => (
            <div key={item.title} className="rounded-[24px] border border-white/10 bg-white/5 p-4">
              <div className="flex items-start gap-3">
                <span className={darkToneClass(item.tone)}>
                  <AlertTriangle className="h-4 w-4" />
                </span>
                <div>
                  <p className="font-semibold text-white">{item.title}</p>
                  <p className="mt-1 text-sm leading-6 text-slate-300">{item.detail}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function toneClass(tone: "high" | "medium" | "low") {
  if (tone === "high") {
    return "flex h-10 w-10 items-center justify-center rounded-2xl bg-rose-50 text-rose-600";
  }
  if (tone === "medium") {
    return "flex h-10 w-10 items-center justify-center rounded-2xl bg-amber-50 text-amber-600";
  }
  return "flex h-10 w-10 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-600";
}

function darkToneClass(tone: "high" | "medium" | "low") {
  if (tone === "high") {
    return "mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-rose-500/15 text-rose-200";
  }
  if (tone === "medium") {
    return "mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-amber-400/15 text-amber-200";
  }
  return "mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-emerald-400/15 text-emerald-200";
}
