import Link from "next/link";
import Image from "next/image";

import { getSettings } from "@/lib/store";

export async function Logo() {
  const settings = await getSettings();

  return (
    <Link href="/" className="flex items-center gap-4">
      <div className="flex items-center gap-3 rounded-[28px] border border-white/10 bg-white/6 px-3 py-2 backdrop-blur">
        <div className="relative flex h-[78px] w-[86px] items-center justify-center">
          <div
            className="absolute inset-0 bg-[linear-gradient(135deg,rgba(255,255,255,0.12),rgba(255,255,255,0.02))] shadow-[0_16px_26px_rgba(15,38,31,0.22)]"
            style={{ clipPath: "polygon(25% 4%, 75% 4%, 100% 50%, 75% 96%, 25% 96%, 0% 50%)" }}
          />
          <Image
            src={settings.platformLogoUrl || "/assets/hse-hive-icon.png"}
            alt={`${settings.brandName} logo`}
            width={74}
            height={74}
            className="relative h-[74px] w-[74px] object-contain"
            priority
          />
        </div>

        {settings.companyLogoUrl ? (
          <>
            <div className="h-10 w-px bg-white/12" />
            <div className="flex h-[64px] min-w-[88px] items-center justify-center rounded-[20px] bg-white/92 px-3 py-2 shadow-sm">
              <img
                src={settings.companyLogoUrl}
                alt={`${settings.companyName} logo`}
                className="h-auto max-h-[46px] w-auto max-w-[96px] object-contain"
              />
            </div>
          </>
        ) : null}
      </div>
      <div>
        <p className="text-sm uppercase tracking-[0.35em] text-teal">{settings.productLabel}</p>
        <h1 className="text-lg font-semibold text-ink">{settings.brandName}</h1>
        {settings.companyLogoUrl ? <p className="text-xs text-slate-400">{settings.companyName}</p> : null}
      </div>
    </Link>
  );
}
