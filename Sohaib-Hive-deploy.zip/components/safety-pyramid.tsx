const layers = [
  { label: "Potential Fatalities", value: 1, className: "bg-[#143127] text-white", width: "w-24" },
  { label: "Serious Injuries", value: 6, className: "bg-[#1f7a4d] text-white", width: "w-40" },
  { label: "Recordables", value: 28, className: "bg-[#52a36f] text-white", width: "w-56" },
  { label: "Near Misses", value: 120, className: "bg-[#8ecb6a] text-ink", width: "w-72" },
  { label: "Unsafe Acts / Conditions", value: 540, className: "bg-[#dff2d7] text-ink", width: "w-80" }
];

export function SafetyPyramid() {
  return (
    <section className="relative overflow-hidden rounded-[32px] border border-white/70 bg-[linear-gradient(180deg,rgba(16,31,25,0.97),rgba(21,45,34,0.94))] p-6 text-white shadow-card">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/40 to-transparent" />
      <div className="absolute -right-16 top-0 h-40 w-40 rounded-full bg-[radial-gradient(circle,rgba(135,184,61,0.38),transparent_70%)]" />
      <p className="text-xs uppercase tracking-[0.28em] text-emerald-200">Fatality Prevention</p>
      <div className="mt-3 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-white">Serious injury and fatality exposure</h2>
          <p className="mt-2 max-w-xl text-sm text-emerald-50/80">
            The base of the pyramid helps predict where serious harm can emerge. More observations and conversations at the bottom reduce the chance of fatal outcomes at the top.
          </p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-right">
          <p className="text-[11px] uppercase tracking-[0.18em] text-emerald-100/70">Signal strength</p>
          <p className="mt-1 text-3xl font-semibold">694</p>
        </div>
      </div>
      <p className="mt-4 text-sm text-emerald-50/70">
        The base of the pyramid helps predict where serious harm can emerge. More observations and conversations at the bottom reduce the chance of fatal outcomes at the top.
      </p>
      <div className="mt-8 flex flex-col items-center gap-3">
        {layers.map((layer) => (
          <div
            key={layer.label}
            className={`${layer.width} rounded-[20px] border border-white/10 px-4 py-3 text-center shadow-[0_18px_40px_rgba(0,0,0,0.18)] ${layer.className}`}
          >
            <p className="text-[11px] uppercase tracking-[0.2em] opacity-80">{layer.label}</p>
            <p className="mt-1 text-2xl font-semibold">{layer.value}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
