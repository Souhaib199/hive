"use client";

import Link from "next/link";
import {
  AlertTriangle,
  Eye,
  ImagePlus,
  Palette,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  SwatchBook,
  Users2
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useMemo, useState, useTransition } from "react";

import type { PlatformSettings, ReportRecord, UserRecord } from "@/lib/types";
import { formatDate } from "@/lib/utils";

type AdminConsoleProps = {
  settings: PlatformSettings;
  users: UserRecord[];
  reports: Array<ReportRecord & { author: UserRecord }>;
};

type TabKey = "brand" | "users" | "monitor";

export function AdminConsole({ settings, users, reports }: AdminConsoleProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [activeTab, setActiveTab] = useState<TabKey>("brand");
  const [settingsState, setSettingsState] = useState(settings);
  const [monitorQuery, setMonitorQuery] = useState("");
  const [monitorStatus, setMonitorStatus] = useState<"ALL" | "DRAFT" | "PUBLISHED" | "ARCHIVED">("ALL");
  const [monitorSeverity, setMonitorSeverity] = useState<"ALL" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL">("ALL");
  const [userForm, setUserForm] = useState({
    name: "",
    email: "",
    role: "BASIC_USER",
    password: ""
  });
  const [error, setError] = useState<string | null>(null);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [uploadingPlatformLogo, setUploadingPlatformLogo] = useState(false);

  const overview = useMemo(
    () => ({
      users: users.length,
      cases: reports.length,
      openActions: reports.reduce(
        (sum, report) => sum + report.actions.filter((action) => action.status !== "CLOSED").length,
        0
      ),
      highPotential: reports.filter(
        (report) => report.potentialSeverity === "HIGH" || report.potentialSeverity === "CRITICAL"
      ).length
    }),
    [reports, users.length]
  );

  const filteredReports = useMemo(() => {
    const query = monitorQuery.trim().toLowerCase();

    return reports.filter((report) => {
      const matchesQuery =
        query.length === 0 ||
        [
          report.title,
          report.site,
          report.department,
          report.author.name,
          report.category,
          report.riskType
        ]
          .join(" ")
          .toLowerCase()
          .includes(query);

      const matchesStatus = monitorStatus === "ALL" || report.status === monitorStatus;
      const matchesSeverity =
        monitorSeverity === "ALL" || report.potentialSeverity === monitorSeverity;

      return matchesQuery && matchesStatus && matchesSeverity;
    });
  }, [monitorQuery, monitorSeverity, monitorStatus, reports]);

  const monitoringSummary = useMemo(
    () => ({
      visibleCases: filteredReports.length,
      visibleOpenActions: filteredReports.reduce(
        (sum, report) => sum + report.actions.filter((action) => action.status !== "CLOSED").length,
        0
      ),
      visibleHighPotential: filteredReports.filter(
        (report) => report.potentialSeverity === "HIGH" || report.potentialSeverity === "CRITICAL"
      ).length,
      visiblePublished: filteredReports.filter((report) => report.status === "PUBLISHED").length
    }),
    [filteredReports]
  );

  async function saveSettings() {
    setError(null);
    const response = await fetch("/api/admin/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(settingsState)
    });

    if (!response.ok) {
      setError("Could not save settings.");
      return;
    }

    router.refresh();
  }

  async function createUser() {
    setError(null);
    const response = await fetch("/api/admin/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(userForm)
    });

    if (!response.ok) {
      const body = await response.json();
      setError(body.error ?? "Could not create user.");
      return;
    }

    setUserForm({ name: "", email: "", role: "BASIC_USER", password: "" });
    router.refresh();
  }

  async function uploadCompanyLogo(file: File) {
    setError(null);
    setUploadingLogo(true);

    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch("/api/admin/company-logo", {
        method: "POST",
        body: formData
      });

      if (!response.ok) {
        const body = await response.json();
        setError(body.error ?? "Could not upload company logo.");
        return;
      }

      const body = await response.json();
      setSettingsState((prev) => ({ ...prev, companyLogoUrl: body.url }));
    } finally {
      setUploadingLogo(false);
    }
  }

  async function uploadPlatformLogo(file: File) {
    setError(null);
    setUploadingPlatformLogo(true);

    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch("/api/admin/platform-logo", {
        method: "POST",
        body: formData
      });

      if (!response.ok) {
        const body = await response.json();
        setError(body.error ?? "Could not upload platform logo.");
        return;
      }

      const body = await response.json();
      setSettingsState((prev) => ({ ...prev, platformLogoUrl: body.url }));
    } finally {
      setUploadingPlatformLogo(false);
    }
  }

  async function updateUserRole(id: string, role: string) {
    await fetch(`/api/admin/users/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ role })
    });
    router.refresh();
  }

  async function removeUser(id: string) {
    await fetch(`/api/admin/users/${id}`, { method: "DELETE" });
    router.refresh();
  }

  return (
    <div className="space-y-6">
      <section className="overflow-hidden rounded-[36px] border border-white/10 bg-[linear-gradient(135deg,#0e231b_0%,#123126_46%,#1f4a38_100%)] p-0 shadow-card">
        <div className="grid gap-0 xl:grid-cols-[1.25fr_0.75fr]">
          <div className="p-8 text-white lg:p-10">
            <p className="text-xs uppercase tracking-[0.34em] text-[#9fd69c]">Admin Control Center</p>
            <h2 className="mt-4 max-w-3xl text-4xl font-semibold leading-tight tracking-[-0.04em]">
              Manage brand identity, permissions, and live governance from a sharper executive workspace.
            </h2>
            <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-200">
              This is the system layer of Sohaib Hive: brand control, theme tuning, product copy, access roles, and live HSE oversight.
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <HeroBadge icon={<Palette className="h-4 w-4" />} label="Theme Studio" />
              <HeroBadge icon={<Users2 className="h-4 w-4" />} label="Role Governance" />
              <HeroBadge icon={<ShieldCheck className="h-4 w-4" />} label="Admin Only" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-px bg-white/10">
            <MetricTile label="Users" value={String(overview.users)} />
            <MetricTile label="Cases" value={String(overview.cases)} />
            <MetricTile label="Open Actions" value={String(overview.openActions)} />
            <MetricTile label="High Potential" value={String(overview.highPotential)} />
          </div>
        </div>
      </section>

      <section className="rounded-[30px] border border-white/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.94),rgba(243,247,244,0.9))] p-3 shadow-card">
        <div className="grid gap-2 md:grid-cols-3">
          <TabButton active={activeTab === "brand"} onClick={() => setActiveTab("brand")} icon={<SwatchBook className="h-4 w-4" />} label="Brand & Theme" description="Product identity and copy" />
          <TabButton active={activeTab === "users"} onClick={() => setActiveTab("users")} icon={<Users2 className="h-4 w-4" />} label="Users & Roles" description="Provisioning and permissions" />
          <TabButton active={activeTab === "monitor"} onClick={() => setActiveTab("monitor")} icon={<Settings2 className="h-4 w-4" />} label="Monitoring" description="Case oversight and control" />
        </div>
      </section>

      {error ? <p className="rounded-2xl bg-rose-50 px-4 py-3 text-sm text-rose-600">{error}</p> : null}

      {activeTab === "brand" ? (
        <div className="grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
          <section className="rounded-[32px] border border-white/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.97),rgba(243,247,244,0.92))] p-6 shadow-card">
            <SectionHeader
              eyebrow="Theme Studio"
              title="Modernize the product identity"
              description="Adjust visual tone, copy, and platform labels from one high-control surface."
            />

            <div className="grid gap-5 md:grid-cols-2">
              <TextInput label="Brand name" value={settingsState.brandName} onChange={(value) => setSettingsState((prev) => ({ ...prev, brandName: value }))} />
              <TextInput label="Product label" value={settingsState.productLabel} onChange={(value) => setSettingsState((prev) => ({ ...prev, productLabel: value }))} />
              <TextInput label="Platform logo URL" value={settingsState.platformLogoUrl} onChange={(value) => setSettingsState((prev) => ({ ...prev, platformLogoUrl: value }))} />
              <TextInput label="Company name" value={settingsState.companyName} onChange={(value) => setSettingsState((prev) => ({ ...prev, companyName: value }))} />
              <TextInput label="Company logo URL" value={settingsState.companyLogoUrl} onChange={(value) => setSettingsState((prev) => ({ ...prev, companyLogoUrl: value }))} />
              <ColorInput label="Primary color" value={settingsState.primaryColor} onChange={(value) => setSettingsState((prev) => ({ ...prev, primaryColor: value }))} />
              <ColorInput label="Accent color" value={settingsState.accentColor} onChange={(value) => setSettingsState((prev) => ({ ...prev, accentColor: value }))} />
              <ColorInput label="Sidebar color" value={settingsState.sidebarColor} onChange={(value) => setSettingsState((prev) => ({ ...prev, sidebarColor: value }))} />
              <ColorInput label="Surface tint" value={settingsState.surfaceTint} onChange={(value) => setSettingsState((prev) => ({ ...prev, surfaceTint: value }))} />
              <TextAreaInput
                label="Dashboard title"
                value={settingsState.dashboardTitle}
                onChange={(value) => setSettingsState((prev) => ({ ...prev, dashboardTitle: value }))}
                className="md:col-span-2"
              />
              <TextAreaInput
                label="Dashboard description"
                value={settingsState.dashboardDescription}
                onChange={(value) => setSettingsState((prev) => ({ ...prev, dashboardDescription: value }))}
                className="md:col-span-2"
              />
              <TextAreaInput
                label="Login title"
                value={settingsState.loginTitle}
                onChange={(value) => setSettingsState((prev) => ({ ...prev, loginTitle: value }))}
                className="md:col-span-2"
              />
              <TextAreaInput
                label="Login description"
                value={settingsState.loginDescription}
                onChange={(value) => setSettingsState((prev) => ({ ...prev, loginDescription: value }))}
                className="md:col-span-2"
              />
              <TextInput label="Body map title" value={settingsState.bodyMapTitle} onChange={(value) => setSettingsState((prev) => ({ ...prev, bodyMapTitle: value }))} />
              <TextAreaInput label="Body map description" value={settingsState.bodyMapDescription} onChange={(value) => setSettingsState((prev) => ({ ...prev, bodyMapDescription: value }))} />
              <div className="md:col-span-2">
                <label className="mb-2 block text-sm font-medium text-slate-700">Platform logo upload</label>
                <label className="flex cursor-pointer items-center justify-between rounded-2xl border border-dashed border-slate-300 bg-white px-4 py-4 text-sm shadow-sm transition hover:border-emerald-300">
                  <div className="flex items-center gap-3">
                    <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700">
                      <ImagePlus className="h-4 w-4" />
                    </span>
                    <div>
                      <p className="font-semibold text-ink">{uploadingPlatformLogo ? "Uploading..." : "Upload platform logo"}</p>
                      <p className="text-xs text-slate-500">This is your HSE hive icon and can be changed later</p>
                    </div>
                  </div>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(event) => {
                      const file = event.target.files?.[0];
                      if (file) {
                        void uploadPlatformLogo(file);
                      }
                    }}
                  />
                  <span className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold uppercase tracking-[0.14em] text-slate-600">
                    Select file
                  </span>
                </label>
              </div>
              <div className="md:col-span-2">
                <label className="mb-2 block text-sm font-medium text-slate-700">Company logo upload</label>
                <label className="flex cursor-pointer items-center justify-between rounded-2xl border border-dashed border-slate-300 bg-white px-4 py-4 text-sm shadow-sm transition hover:border-emerald-300">
                  <div className="flex items-center gap-3">
                    <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700">
                      <ImagePlus className="h-4 w-4" />
                    </span>
                    <div>
                      <p className="font-semibold text-ink">{uploadingLogo ? "Uploading..." : "Upload company logo"}</p>
                      <p className="text-xs text-slate-500">PNG, JPG, or SVG-like flat brand image</p>
                    </div>
                  </div>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(event) => {
                      const file = event.target.files?.[0];
                      if (file) {
                        void uploadCompanyLogo(file);
                      }
                    }}
                  />
                  <span className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold uppercase tracking-[0.14em] text-slate-600">
                    Select file
                  </span>
                </label>
              </div>
            </div>

            <div className="mt-6 flex items-center gap-3">
              <button
                type="button"
                onClick={() => startTransition(saveSettings)}
                className="rounded-2xl bg-clay px-5 py-3 text-sm font-semibold text-white shadow-[0_16px_34px_rgba(47,143,98,0.24)]"
              >
                {isPending ? "Saving..." : "Publish settings"}
              </button>
            </div>
          </section>

          <section className="rounded-[32px] border border-white/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.97),rgba(243,247,244,0.92))] p-6 shadow-card">
            <SectionHeader
              eyebrow="Live Preview"
              title="Brand system snapshot"
              description="See the current theme direction before saving."
            />
            <div
              className="overflow-hidden rounded-[30px] border border-slate-100 shadow-sm"
              style={{ background: `linear-gradient(135deg, ${settingsState.sidebarColor} 0%, ${settingsState.primaryColor} 100%)` }}
            >
              <div className="border-b border-white/10 p-6 text-white">
                <p className="text-xs uppercase tracking-[0.3em] text-white/70">{settingsState.productLabel}</p>
                <h3 className="mt-3 text-3xl font-semibold">{settingsState.brandName}</h3>
                <p className="mt-3 max-w-xl text-sm text-white/80">{settingsState.dashboardDescription}</p>
              </div>
              <div className="grid gap-4 bg-[color:var(--brand-surface)] p-6 md:grid-cols-2">
                <PreviewCard title="Primary" value={settingsState.primaryColor} style={{ backgroundColor: settingsState.primaryColor }} />
                <PreviewCard title="Accent" value={settingsState.accentColor} style={{ backgroundColor: settingsState.accentColor }} />
                <PreviewCard title="Sidebar" value={settingsState.sidebarColor} style={{ backgroundColor: settingsState.sidebarColor }} />
                <PreviewCard title="Surface" value={settingsState.surfaceTint} style={{ backgroundColor: settingsState.surfaceTint, color: "#143127" }} />
              </div>
              <div className="border-t border-slate-100 bg-white p-6">
                <p className="text-xs uppercase tracking-[0.18em] text-slate-500">Brand lockup preview</p>
                <div className="mt-4 flex items-center gap-4 rounded-[24px] border border-slate-100 bg-slate-50/80 p-4">
                  <div className="relative flex h-[72px] w-[80px] items-center justify-center">
                    <div
                      className="absolute inset-0 bg-[linear-gradient(135deg,rgba(20,49,39,0.08),rgba(47,143,98,0.12))]"
                      style={{ clipPath: "polygon(25% 4%, 75% 4%, 100% 50%, 75% 96%, 25% 96%, 0% 50%)" }}
                    />
                    <img src={settingsState.platformLogoUrl || "/assets/hse-hive-icon.png"} alt="HSE hive icon preview" className="relative h-[68px] w-[68px] object-contain" />
                  </div>
                  {settingsState.companyLogoUrl ? (
                    <>
                      <div className="h-10 w-px bg-slate-200" />
                      <div className="flex h-[60px] min-w-[92px] items-center justify-center rounded-[18px] bg-white px-3 py-2 shadow-sm">
                        <img src={settingsState.companyLogoUrl} alt="Company logo preview" className="h-auto max-h-[42px] w-auto max-w-[96px] object-contain" />
                      </div>
                    </>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="mt-5 rounded-[24px] border border-emerald-100 bg-emerald-50/70 p-4 text-sm text-emerald-800">
              Theme edits apply across the dashboard shell, login screen, body-map section, and brand surfaces.
            </div>
          </section>
        </div>
      ) : null}

      {activeTab === "users" ? (
        <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
          <section className="rounded-[32px] border border-white/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.97),rgba(243,247,244,0.92))] p-6 shadow-card">
            <SectionHeader
              eyebrow="User Provisioning"
              title="Create new access profiles"
              description="Provision admins, superusers, and basic users from a cleaner role-management form."
            />

            <div className="grid gap-4">
              <TextInput label="Full name" value={userForm.name} onChange={(value) => setUserForm((prev) => ({ ...prev, name: value }))} />
              <TextInput label="Email" value={userForm.email} onChange={(value) => setUserForm((prev) => ({ ...prev, email: value }))} />
              <SelectInput
                label="Role"
                value={userForm.role}
                options={["ADMIN", "SUPERUSER", "BASIC_USER"]}
                onChange={(value) => setUserForm((prev) => ({ ...prev, role: value }))}
              />
              <TextInput label="Temporary password" type="password" value={userForm.password} onChange={(value) => setUserForm((prev) => ({ ...prev, password: value }))} />
            </div>

            <div className="mt-6">
              <button type="button" onClick={() => startTransition(createUser)} className="rounded-2xl bg-ink px-5 py-3 text-sm font-semibold text-white shadow-[0_16px_30px_rgba(20,49,39,0.18)]">
                Add user
              </button>
            </div>
          </section>

          <section className="rounded-[32px] border border-white/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.97),rgba(243,247,244,0.92))] p-6 shadow-card">
            <SectionHeader
              eyebrow="Directory"
              title="Permission matrix"
              description="Manage roles with a denser, more product-like roster view."
            />
            <div className="space-y-3">
              {users.map((user) => (
                <div key={user.id} className="rounded-[26px] border border-white bg-white/85 p-4 shadow-sm transition hover:-translate-y-0.5 hover:bg-white">
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                    <div>
                      <div className="flex items-center gap-3">
                        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[linear-gradient(135deg,#143127,#2f8f62)] text-sm font-semibold text-white shadow-sm">
                          {user.name
                            .split(" ")
                            .map((part) => part[0])
                            .join("")
                            .slice(0, 2)}
                        </div>
                        <div>
                          <p className="font-semibold text-ink">{user.name}</p>
                          <p className="text-sm text-slate-500">{user.email}</p>
                        </div>
                      </div>
                      <div className="mt-3 flex flex-wrap items-center gap-2">
                        <span className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-600">
                          {user.role}
                        </span>
                        <span className="text-xs uppercase tracking-[0.16em] text-slate-400">Joined {formatDate(user.createdAt)}</span>
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-3">
                      <select
                        value={user.role}
                        onChange={(event) => updateUserRole(user.id, event.target.value)}
                        className="rounded-2xl border border-slate-200 bg-white px-4 py-2.5 text-sm shadow-sm"
                      >
                        <option value="ADMIN">ADMIN</option>
                        <option value="SUPERUSER">SUPERUSER</option>
                        <option value="BASIC_USER">BASIC_USER</option>
                      </select>
                      <button
                        type="button"
                        onClick={() => removeUser(user.id)}
                        className="rounded-2xl border border-rose-200 bg-white px-4 py-2.5 text-sm font-semibold text-rose-600 shadow-sm"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      ) : null}

      {activeTab === "monitor" ? (
        <section className="rounded-[32px] border border-white/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.97),rgba(243,247,244,0.92))] p-6 shadow-card">
          <SectionHeader
            eyebrow="Platform Monitoring"
            title="Administrative case oversight"
            description="Search the live case register, isolate high-potential exposure, and jump directly into review or editing."
          />

          <div className="grid gap-4 md:grid-cols-4">
            <SummaryBox label="Visible cases" value={String(monitoringSummary.visibleCases)} icon={<Sparkles className="h-4 w-4 text-emerald-600" />} />
            <SummaryBox label="Published" value={String(monitoringSummary.visiblePublished)} icon={<ShieldCheck className="h-4 w-4 text-emerald-600" />} />
            <SummaryBox label="Open actions" value={String(monitoringSummary.visibleOpenActions)} icon={<Settings2 className="h-4 w-4 text-emerald-600" />} />
            <SummaryBox label="High potential" value={String(monitoringSummary.visibleHighPotential)} icon={<AlertTriangle className="h-4 w-4 text-amber-600" />} />
          </div>

          <div className="mt-6 grid gap-4 lg:grid-cols-[1.4fr_0.8fr_0.8fr]">
            <label className="flex items-center gap-3 rounded-[24px] border border-slate-200 bg-white px-4 py-3 shadow-sm">
              <Search className="h-4 w-4 text-slate-400" />
              <input
                value={monitorQuery}
                onChange={(event) => setMonitorQuery(event.target.value)}
                placeholder="Search by case, site, department, owner, or risk"
                className="w-full bg-transparent text-sm text-slate-700 placeholder:text-slate-400"
              />
            </label>

            <SelectInput
              label="Status"
              value={monitorStatus}
              options={["ALL", "DRAFT", "PUBLISHED", "ARCHIVED"]}
              onChange={(value) => setMonitorStatus(value as typeof monitorStatus)}
            />

            <SelectInput
              label="Potential severity"
              value={monitorSeverity}
              options={["ALL", "LOW", "MEDIUM", "HIGH", "CRITICAL"]}
              onChange={(value) => setMonitorSeverity(value as typeof monitorSeverity)}
            />
          </div>

          <div className="mt-6 overflow-hidden rounded-[28px] border border-slate-100 bg-white shadow-sm">
            <table className="min-w-full text-left">
              <thead className="bg-slate-50/90 text-xs uppercase tracking-[0.18em] text-slate-500">
                <tr>
                  <th className="px-5 py-4">Case</th>
                  <th className="px-5 py-4">Site</th>
                  <th className="px-5 py-4">Owner</th>
                  <th className="px-5 py-4">Severity</th>
                  <th className="px-5 py-4">Status</th>
                  <th className="px-5 py-4">Open Actions</th>
                  <th className="px-5 py-4">Controls</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {filteredReports.map((report) => (
                  <tr key={report.id} className="hover:bg-emerald-50/30">
                    <td className="px-5 py-4">
                      <p className="font-semibold text-ink">{report.title}</p>
                      <p className="mt-1 text-sm text-slate-500">{report.category}</p>
                    </td>
                    <td className="px-5 py-4 text-sm text-slate-600">{report.site}</td>
                    <td className="px-5 py-4 text-sm text-slate-600">{report.author.name}</td>
                    <td className="px-5 py-4">
                      <span
                        className={`rounded-full px-3 py-1 text-xs font-semibold ${
                          report.potentialSeverity === "CRITICAL"
                            ? "bg-rose-100 text-rose-700"
                            : report.potentialSeverity === "HIGH"
                              ? "bg-amber-100 text-amber-700"
                              : report.potentialSeverity === "MEDIUM"
                                ? "bg-sky-100 text-sky-700"
                                : "bg-emerald-100 text-emerald-700"
                        }`}
                      >
                        {report.potentialSeverity}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <span className="rounded-full border border-slate-200 bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700">{report.status}</span>
                    </td>
                    <td className="px-5 py-4 text-sm font-semibold text-ink">
                      {report.actions.filter((action) => action.status !== "CLOSED").length}
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex flex-wrap gap-2">
                        <Link
                          href={`/reports/${report.id}`}
                          className="inline-flex items-center gap-1 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700"
                        >
                          <Eye className="h-3.5 w-3.5" />
                          View
                        </Link>
                        <Link
                          href={`/reports/${report.id}/edit`}
                          className="inline-flex items-center gap-1 rounded-xl bg-ink px-3 py-2 text-xs font-semibold text-white"
                        >
                          Edit
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredReports.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-5 py-10 text-center">
                      <div className="mx-auto max-w-md rounded-[24px] border border-dashed border-slate-200 bg-slate-50/70 px-6 py-8">
                        <AlertTriangle className="mx-auto h-6 w-6 text-slate-400" />
                        <p className="mt-3 font-semibold text-ink">No cases match this monitoring view</p>
                        <p className="mt-2 text-sm text-slate-500">
                          Change the filters or search terms to bring records back into focus.
                        </p>
                      </div>
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </section>
      ) : null}
    </div>
  );
}

function HeroBadge({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/10 px-3 py-2 text-xs font-semibold uppercase tracking-[0.16em] text-white/90 backdrop-blur">
      {icon}
      {label}
    </span>
  );
}

function MetricTile({ label, value }: { label: string; value: string }) {
  return (
    <div className="border-l border-t border-white/10 bg-black/5 p-6 text-white">
      <p className="text-xs uppercase tracking-[0.18em] text-white/60">{label}</p>
      <p className="mt-3 text-4xl font-semibold tracking-tight">{value}</p>
    </div>
  );
}

function TabButton({
  active,
  onClick,
  icon,
  label,
  description
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  description: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-[24px] border px-4 py-4 text-left transition ${
        active
          ? "border-emerald-200 bg-[linear-gradient(135deg,rgba(20,49,39,0.96),rgba(47,143,98,0.9))] text-white shadow-sm"
          : "border-transparent bg-transparent text-slate-600 hover:border-slate-200 hover:bg-white"
      }`}
    >
      <div className="flex items-center gap-2 text-sm font-semibold">
        {icon}
        {label}
      </div>
      <p className={`mt-2 text-xs leading-5 ${active ? "text-white/75" : "text-slate-500"}`}>{description}</p>
    </button>
  );
}

function SectionHeader({
  eyebrow,
  title,
  description
}: {
  eyebrow: string;
  title: string;
  description: string;
}) {
  return (
    <div className="mb-6">
      <p className="text-xs uppercase tracking-[0.28em] text-slate-500">{eyebrow}</p>
      <h2 className="mt-2 text-2xl font-semibold text-ink">{title}</h2>
      <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">{description}</p>
    </div>
  );
}

function PreviewCard({
  title,
  value,
  style
}: {
  title: string;
  value: string;
  style: React.CSSProperties;
}) {
  return (
    <div className="rounded-[24px] border border-slate-100 bg-white p-4 shadow-sm">
      <div className="h-24 rounded-2xl shadow-inner" style={style} />
      <p className="mt-3 text-xs uppercase tracking-[0.16em] text-slate-500">{title}</p>
      <p className="mt-2 font-semibold text-ink">{value}</p>
    </div>
  );
}

function SummaryBox({ label, value, icon }: { label: string; value: string; icon: React.ReactNode }) {
  return (
    <div className="rounded-[24px] border border-white bg-white/85 p-5 shadow-sm">
      <div className="flex items-center justify-between gap-3">
        <p className="text-xs uppercase tracking-[0.18em] text-slate-500">{label}</p>
        <span className="flex h-9 w-9 items-center justify-center rounded-2xl bg-slate-50">{icon}</span>
      </div>
      <p className="mt-3 text-4xl font-semibold tracking-tight text-ink">{value}</p>
    </div>
  );
}

function TextInput({
  label,
  value,
  onChange,
  type = "text"
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-medium text-slate-700">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm shadow-sm transition focus:border-slate-300"
      />
    </div>
  );
}

function TextAreaInput({
  label,
  value,
  onChange,
  className
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  className?: string;
}) {
  return (
    <div className={className}>
      <label className="mb-2 block text-sm font-medium text-slate-700">{label}</label>
      <textarea
        rows={4}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm shadow-sm transition focus:border-slate-300"
      />
    </div>
  );
}

function ColorInput({
  label,
  value,
  onChange
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-medium text-slate-700">{label}</label>
      <div className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm transition focus-within:border-slate-300">
        <input type="color" value={value} onChange={(event) => onChange(event.target.value)} className="h-10 w-12 border-0 bg-transparent" />
        <input value={value} onChange={(event) => onChange(event.target.value)} className="flex-1 bg-transparent text-sm outline-none" />
      </div>
    </div>
  );
}

function SelectInput({
  label,
  value,
  options,
  onChange
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (value: string) => void;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-medium text-slate-700">{label}</label>
      <select value={value} onChange={(event) => onChange(event.target.value)} className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm shadow-sm transition focus:border-slate-300">
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </div>
  );
}
