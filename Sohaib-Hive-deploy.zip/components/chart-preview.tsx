type ChartPoint = {
  label: string;
  value: number;
};

export function ChartPreview({ data }: { data: ChartPoint[] }) {
  const maxValue = Math.max(...data.map((point) => point.value), 1);

  return (
    <div className="rounded-[28px] border border-white/80 bg-white/80 p-6 shadow-card">
      <div className="flex items-end gap-4">
        {data.map((point) => (
          <div key={point.label} className="flex flex-1 flex-col items-center gap-3">
            <div className="flex h-52 w-full items-end rounded-3xl bg-slate-100 p-3">
              <div
                className="w-full rounded-2xl bg-gradient-to-b from-teal to-ink"
                style={{
                  height: `${Math.max((point.value / maxValue) * 100, 12)}%`
                }}
              />
            </div>
            <div className="text-center">
              <p className="text-sm font-semibold text-ink">{point.value}</p>
              <p className="text-xs uppercase tracking-[0.18em] text-slate-500">{point.label}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
