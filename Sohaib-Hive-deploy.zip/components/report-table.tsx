import Link from "next/link";
import { ArrowUpRight, Clock3 } from "lucide-react";

import type { ReportRecord, UserRecord } from "@/lib/types";
import { formatDate } from "@/lib/utils";

type ReportWithAuthor = ReportRecord & {
  author: UserRecord;
};

export function ReportTable({ reports }: { reports: ReportWithAuthor[] }) {
  return (
    <div className="overflow-hidden rounded-[34px] border border-white/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.96),rgba(241,246,242,0.9))] shadow-card backdrop-blur">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 px-6 py-5">
        <div>
          <p className="text-xs uppercase tracking-[0.28em] text-slate-500">Register</p>
          <h2 className="mt-2 text-2xl font-semibold text-ink">Case oversight</h2>
        </div>
        <div className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white/80 px-4 py-2 text-sm text-slate-500 shadow-sm">
          <Clock3 className="h-4 w-4 text-emerald-600" />
          {reports.length} active records
        </div>
      </div>
      <table className="min-w-full text-left">
        <thead className="border-b border-slate-100 bg-slate-50/70 text-xs uppercase tracking-[0.22em] text-slate-500">
          <tr>
            <th className="px-6 py-4 font-medium">Entry</th>
            <th className="px-6 py-4 font-medium">Category</th>
            <th className="px-6 py-4 font-medium">Site</th>
            <th className="px-6 py-4 font-medium">Severity</th>
            <th className="px-6 py-4 font-medium">Open Actions</th>
            <th className="px-6 py-4 font-medium">Status</th>
            <th className="px-6 py-4 font-medium">Updated</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {reports.map((report) => (
            <tr key={report.id} className="text-sm text-slate-700 transition hover:bg-white/70">
              <td className="px-6 py-4">
                <Link href={`/reports/${report.id}`} className="group block">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="font-semibold text-ink transition group-hover:text-emerald-700">{report.title}</p>
                      <p className="mt-1 text-slate-500">{report.author.name} · {report.department}</p>
                    </div>
                    <ArrowUpRight className="h-4 w-4 text-slate-300 transition group-hover:text-emerald-600" />
                  </div>
                </Link>
              </td>
              <td className="px-6 py-4">
                <span className="rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-semibold uppercase tracking-[0.14em] text-slate-700">
                  {report.category}
                </span>
              </td>
              <td className="px-6 py-4 font-medium text-slate-600">{report.site}</td>
              <td className="px-6 py-4">
                <span className="rounded-full border border-amber-100 bg-amber-50 px-3 py-1 text-xs font-semibold text-amber-700">
                  {report.potentialSeverity}
                </span>
              </td>
              <td className="px-6 py-4">
                <span className="rounded-full border border-emerald-100 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                  {report.actions.filter((action) => action.status !== "CLOSED").length} open
                </span>
              </td>
              <td className="px-6 py-4">
                <span className="rounded-full border border-slate-200 bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700">{report.status}</span>
              </td>
              <td className="px-6 py-4 text-slate-500">{formatDate(report.updatedAt)}</td>
            </tr>
          ))}
          {reports.length === 0 ? (
            <tr>
              <td colSpan={7} className="px-6 py-16 text-center text-sm text-slate-500">
                No reports match the current search and filters.
              </td>
            </tr>
          ) : null}
        </tbody>
      </table>
    </div>
  );
}
