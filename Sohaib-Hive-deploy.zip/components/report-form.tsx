"use client";

import { AlertTriangle, ClipboardCheck, FileBarChart2, ShieldCheck, Wrench } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";

import {
  AUDIT_TYPE_OPTIONS,
  BODY_PART_OPTIONS,
  CATEGORY_OPTIONS,
  CAUSE_OPTIONS,
  DEPARTMENT_OPTIONS,
  DEVIATION_OPTIONS,
  EQUIPMENT_OPTIONS,
  INCIDENT_TYPE_OPTIONS,
  OBSERVATION_TYPE_OPTIONS,
  PROCESS_OPTIONS,
  RISK_TYPE_OPTIONS,
  SEVERITY_OPTIONS,
  SITE_OPTIONS,
  STATUS_OPTIONS,
  SYSTEM_OPTIONS,
  VISIBILITY_OPTIONS,
  WORKFLOW_STAGE_OPTIONS
} from "@/lib/lookups";
import type { ReportRecord } from "@/lib/types";

const defaultChartData = JSON.stringify(
  [
    { label: "Week 1", value: 4 },
    { label: "Week 2", value: 7 },
    { label: "Week 3", value: 3 }
  ],
  null,
  2
);

const defaultActions = JSON.stringify(
  [
    { title: "Close PPE gap", owner: "Supervisor", dueDate: "2026-04-08", status: "OPEN" },
    { title: "Verify corrective action", owner: "HSE Manager", dueDate: "2026-04-12", status: "IN_PROGRESS" }
  ],
  null,
  2
);

type ReportFormProps = {
  mode?: "create" | "edit";
  initialData?: ReportRecord;
};

export function ReportForm({ mode = "create", initialData }: ReportFormProps) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();
  const isEdit = mode === "edit" && initialData;
  const [selectedCategory, setSelectedCategory] = useState(initialData?.category ?? "ACCIDENT");

  const submitUrl = isEdit ? `/api/reports/${initialData.id}` : "/api/reports";
  const submitMethod = isEdit ? "PUT" : "POST";

  return (
    <form
      className="space-y-6"
      onSubmit={(event) => {
        event.preventDefault();
        setError(null);
        const formData = new FormData(event.currentTarget);

        startTransition(async () => {
          let chartData;
          let actions;

          try {
            chartData = JSON.parse(String(formData.get("chartData")));
            actions = JSON.parse(String(formData.get("actions")));
          } catch {
            setError("Trend data and actions must be valid JSON.");
            return;
          }

          const response = await fetch(submitUrl, {
            method: submitMethod,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              caseNumber: formData.get("caseNumber"),
              title: formData.get("title"),
              description: formData.get("description"),
              category: formData.get("category"),
              workflowStage: formData.get("workflowStage"),
              focalPerson: formData.get("focalPerson"),
              responsibleUnit: formData.get("responsibleUnit"),
              incidentType: formData.get("incidentType"),
              observationType: formData.get("observationType"),
              auditType: formData.get("auditType"),
              managementRemarks: formData.get("managementRemarks"),
              consequenceSummary: formData.get("consequenceSummary"),
              investigationStartDate: formData.get("investigationStartDate"),
              resolutionDate: formData.get("resolutionDate"),
              seriousFinding: formData.get("seriousFinding") === "on",
              hasNonConformance: formData.get("hasNonConformance") === "on",
              site: formData.get("site"),
              department: formData.get("department"),
              reportedBy: formData.get("reportedBy"),
              incidentDate: formData.get("incidentDate"),
              severity: formData.get("severity"),
              potentialSeverity: formData.get("potentialSeverity"),
              bodyPart: formData.get("bodyPart"),
              riskType: formData.get("riskType"),
              process: formData.get("process"),
              system: formData.get("system"),
              equipment: formData.get("equipment"),
              deviation: formData.get("deviation"),
              cause: formData.get("cause"),
              personsInvolved: formData.get("personsInvolved"),
              lostTimeDays: formData.get("lostTimeDays"),
              trainingHours: formData.get("trainingHours"),
              auditScore: formData.get("auditScore"),
              correctiveActionSummary: formData.get("correctiveActionSummary"),
              rootCause: formData.get("rootCause"),
              status: formData.get("status"),
              visibility: formData.get("visibility"),
              periodLabel: formData.get("periodLabel"),
              metricValue: formData.get("metricValue"),
              metricDelta: formData.get("metricDelta"),
              chartData,
              actions
            })
          });

          if (!response.ok) {
            const body = await response.json();
            setError(body.error ?? `Could not ${isEdit ? "update" : "create"} entry.`);
            return;
          }

          const body = await response.json();
          router.replace(`/reports/${body.report.id}`);
          router.refresh();
        });
      }}
    >
      <SectionCard
        eyebrow="Workflow"
        title={isEdit ? "Update the HSE case with the latest investigation data" : "Create a structured HSE case"}
        description="This modern form keeps the full HSE record in one place: event details, classification, severity, causes, corrective actions, and trend data."
      >
        <div className="flex flex-wrap gap-3">
          <Chip>Editable</Chip>
          <Chip>Action tracking</Chip>
          <Chip>Severity-based</Chip>
          <Chip>Modern HSE workflow</Chip>
        </div>
      </SectionCard>

      <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        <div className="space-y-6">
          <SectionCard
            eyebrow="Where And What"
            title="Capture the event and business context"
            description="Inspired by your original form structure, but cleaner and easier to scan."
            icon={<ClipboardCheck className="h-5 w-5" />}
          >
            <div className="grid gap-5 md:grid-cols-2">
              <TextField name="caseNumber" label="Case number" defaultValue={initialData?.caseNumber ?? "Auto generated on save"} className="md:col-span-2" disabled={!isEdit} />
              <TextField name="title" label="Entry title" defaultValue={initialData?.title} className="md:col-span-2" />
              <TextAreaField name="description" label="HSE description" rows={5} defaultValue={initialData?.description} className="md:col-span-2" />
              <FieldSelect name="category" label="Category" options={[...CATEGORY_OPTIONS]} defaultValue={initialData?.category} onChange={setSelectedCategory} />
              <FieldSelect name="workflowStage" label="Workflow stage" options={[...WORKFLOW_STAGE_OPTIONS]} defaultValue={initialData?.workflowStage} />
              <FieldSelect name="site" label="Site" options={[...SITE_OPTIONS]} defaultValue={initialData?.site} />
              <FieldSelect name="department" label="Department" options={[...DEPARTMENT_OPTIONS]} defaultValue={initialData?.department} />
              <TextField name="reportedBy" label="Reported by" defaultValue={initialData?.reportedBy ?? "Supervisor"} />
              <TextField name="focalPerson" label="Focal person" defaultValue={initialData?.focalPerson ?? initialData?.reportedBy ?? "HSE Coordinator"} />
              <TextField name="responsibleUnit" label="Responsible unit" defaultValue={initialData?.responsibleUnit ?? initialData?.department ?? "Operations"} />
              <TextField name="incidentDate" label="Event date" defaultValue={initialData?.incidentDate ?? "2026-04-01"} />
              <TextField name="investigationStartDate" label="Investigation start" defaultValue={initialData?.investigationStartDate ?? initialData?.incidentDate ?? "2026-04-01"} />
              <TextField name="resolutionDate" label="Resolution date" defaultValue={initialData?.resolutionDate ?? "2026-04-07"} />
              <TextField name="periodLabel" label="Period label" defaultValue={initialData?.periodLabel ?? "April 2026"} />
            </div>
          </SectionCard>

          <SectionCard
            eyebrow="Module Workflow"
            title={getModuleTitle(selectedCategory)}
            description={getModuleDescription(selectedCategory)}
            icon={<ShieldCheck className="h-5 w-5" />}
          >
            <div className="grid gap-5 md:grid-cols-2">
              <FieldSelect name="incidentType" label="Incident type" options={[...INCIDENT_TYPE_OPTIONS]} defaultValue={initialData?.incidentType} />
              <FieldSelect name="observationType" label="Observation type" options={[...OBSERVATION_TYPE_OPTIONS]} defaultValue={initialData?.observationType} />
              <FieldSelect name="auditType" label="Audit type" options={[...AUDIT_TYPE_OPTIONS]} defaultValue={initialData?.auditType} />
              <CheckField name="seriousFinding" label="Serious finding requires follow-up" defaultChecked={initialData?.seriousFinding ?? false} />
              <CheckField name="hasNonConformance" label="Non-conformance identified" defaultChecked={initialData?.hasNonConformance ?? false} />
              <TextAreaField
                name="consequenceSummary"
                label="Consequences / loss potential"
                rows={4}
                defaultValue={initialData?.consequenceSummary ?? "Summarize actual and potential consequences, operational loss, or exposure."}
                className="md:col-span-2"
              />
              <TextAreaField
                name="managementRemarks"
                label="Management remarks"
                rows={4}
                defaultValue={initialData?.managementRemarks ?? "Management review pending."}
                className="md:col-span-2"
              />
            </div>
          </SectionCard>

          <SectionCard
            eyebrow="Classification"
            title="Classify risk, process, and exposure"
            description="These fields bring your old classification concept into the new product with modern dropdowns."
            icon={<ShieldCheck className="h-5 w-5" />}
          >
            <div className="grid gap-5 md:grid-cols-2">
              <FieldSelect name="bodyPart" label="Body part" options={[...BODY_PART_OPTIONS]} defaultValue={initialData?.bodyPart} />
              <FieldSelect name="riskType" label="Risk type" options={[...RISK_TYPE_OPTIONS]} defaultValue={initialData?.riskType} />
              <FieldSelect name="process" label="Work process" options={[...PROCESS_OPTIONS]} defaultValue={initialData?.process} />
              <FieldSelect name="system" label="System involved" options={[...SYSTEM_OPTIONS]} defaultValue={initialData?.system} />
              <FieldSelect name="equipment" label="Equipment involved" options={[...EQUIPMENT_OPTIONS]} defaultValue={initialData?.equipment} />
              <FieldSelect name="deviation" label="Deviation" options={[...DEVIATION_OPTIONS]} defaultValue={initialData?.deviation} />
              <FieldSelect name="cause" label="Cause" options={[...CAUSE_OPTIONS]} defaultValue={initialData?.cause} className="md:col-span-2" />
            </div>
          </SectionCard>

          <SectionCard
            eyebrow="Investigation"
            title="Document findings and corrective direction"
            description="Keep the root cause and corrective summary visible, editable, and ready for leadership review."
            icon={<AlertTriangle className="h-5 w-5" />}
          >
            <div className="grid gap-5">
              <TextAreaField
                name="rootCause"
                label="Root cause"
                rows={4}
                defaultValue={initialData?.rootCause ?? "Procedure not consistently followed in the field."}
              />
              <TextAreaField
                name="correctiveActionSummary"
                label="Corrective action summary"
                rows={4}
                defaultValue={initialData?.correctiveActionSummary ?? "Reinforce controls, assign owner, and verify closure."}
              />
            </div>
          </SectionCard>
        </div>

        <div className="space-y-6">
          <SectionCard
            eyebrow="Severity And KPIs"
            title="Score the case and quantify impact"
            description="This panel keeps the high-signal numbers together for management review."
            icon={<FileBarChart2 className="h-5 w-5" />}
          >
            <div className="grid gap-5 md:grid-cols-2">
              <FieldSelect name="severity" label="Actual severity" options={[...SEVERITY_OPTIONS]} defaultValue={initialData?.severity} />
              <FieldSelect
                name="potentialSeverity"
                label="Potential severity"
                options={[...SEVERITY_OPTIONS]}
                defaultValue={initialData?.potentialSeverity}
              />
              <FieldSelect name="status" label="Status" options={[...STATUS_OPTIONS]} defaultValue={initialData?.status} />
              <FieldSelect name="visibility" label="Visibility" options={[...VISIBILITY_OPTIONS]} defaultValue={initialData?.visibility} />
              <NumberField name="metricValue" label="KPI value" defaultValue={String(initialData?.metricValue ?? 12)} step="0.01" />
              <NumberField name="metricDelta" label="Change %" defaultValue={String(initialData?.metricDelta ?? -8.5)} step="0.1" />
              <NumberField name="personsInvolved" label="Persons involved" defaultValue={String(initialData?.personsInvolved ?? 1)} step="1" />
              <NumberField name="lostTimeDays" label="Lost time days" defaultValue={String(initialData?.lostTimeDays ?? 0)} step="1" />
              <NumberField name="trainingHours" label="Training hours" defaultValue={String(initialData?.trainingHours ?? 0)} step="0.5" />
              <NumberField name="auditScore" label="Audit score" defaultValue={String(initialData?.auditScore ?? 80)} step="1" />
            </div>
          </SectionCard>

          <SectionCard
            eyebrow="Action Plan"
            title="Own the closure workflow"
            description="Paste or edit the action JSON now; we can convert this into a fully interactive action builder next."
            icon={<Wrench className="h-5 w-5" />}
          >
            <TextAreaField
              name="actions"
              label="Actions JSON"
              rows={12}
              mono
              defaultValue={JSON.stringify(initialData?.actions ?? JSON.parse(defaultActions), null, 2)}
            />
          </SectionCard>

          <SectionCard
            eyebrow="Trend"
            title="Track how the signal is moving"
            description="Keep a compact time-series payload ready for dashboards, monthly reviews, and charts."
          >
            <TextAreaField
              name="chartData"
              label="Trend data JSON"
              rows={12}
              mono
              defaultValue={JSON.stringify(initialData?.chartData ?? JSON.parse(defaultChartData), null, 2)}
            />
          </SectionCard>
        </div>
      </div>

      {error ? <p className="rounded-2xl bg-rose-50 px-4 py-3 text-sm text-rose-600">{error}</p> : null}

      <div className="flex flex-col gap-3 rounded-[28px] border border-white/70 bg-white/85 p-5 shadow-card sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-sm font-semibold text-ink">{isEdit ? "Update and preserve the investigation trail" : "Create a clean, review-ready HSE entry"}</p>
          <p className="text-sm text-slate-500">Everything remains editable after save, including actions, severity, and classification.</p>
        </div>
        <div className="flex gap-3">
          {isEdit ? (
            <button
              type="button"
              onClick={() => router.back()}
              className="rounded-2xl border border-slate-200 px-5 py-3 text-sm font-semibold text-slate-700"
            >
              Cancel
            </button>
          ) : null}
          <button type="submit" className="rounded-2xl bg-clay px-5 py-3 text-sm font-semibold text-white transition hover:opacity-90">
            {isPending ? (isEdit ? "Saving changes..." : "Saving entry...") : isEdit ? "Save changes" : "Create HSE entry"}
          </button>
        </div>
      </div>
    </form>
  );
}

function SectionCard({
  eyebrow,
  title,
  description,
  icon,
  children
}: {
  eyebrow: string;
  title: string;
  description: string;
  icon?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-[32px] border border-white/80 bg-white/85 p-6 shadow-card backdrop-blur">
      <div className="mb-6 flex items-start justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-[0.28em] text-teal">{eyebrow}</p>
          <h2 className="mt-2 text-2xl font-semibold text-ink">{title}</h2>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">{description}</p>
        </div>
        {icon ? <div className="rounded-2xl bg-emerald-50 p-3 text-teal">{icon}</div> : null}
      </div>
      {children}
    </section>
  );
}

function Chip({ children }: { children: React.ReactNode }) {
  return <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold uppercase tracking-[0.16em] text-teal">{children}</span>;
}

function TextField({
  label,
  name,
  defaultValue,
  className,
  disabled = false
}: {
  label: string;
  name: string;
  defaultValue?: string;
  className?: string;
  disabled?: boolean;
}) {
  return (
    <div className={className}>
      <label htmlFor={name} className="mb-2 block text-sm font-medium text-slate-700">
        {label}
      </label>
      <input
        id={name}
        name={name}
        required
        defaultValue={defaultValue}
        disabled={disabled}
        className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm shadow-sm disabled:bg-slate-50 disabled:text-slate-400"
      />
    </div>
  );
}

function NumberField({
  label,
  name,
  defaultValue,
  step
}: {
  label: string;
  name: string;
  defaultValue: string;
  step: string;
}) {
  return (
    <div>
      <label htmlFor={name} className="mb-2 block text-sm font-medium text-slate-700">
        {label}
      </label>
      <input
        id={name}
        name={name}
        type="number"
        step={step}
        defaultValue={defaultValue}
        className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm shadow-sm"
      />
    </div>
  );
}

function TextAreaField({
  label,
  name,
  rows,
  defaultValue,
  mono = false,
  className
}: {
  label: string;
  name: string;
  rows: number;
  defaultValue?: string;
  mono?: boolean;
  className?: string;
}) {
  return (
    <div className={className}>
      <label htmlFor={name} className="mb-2 block text-sm font-medium text-slate-700">
        {label}
      </label>
      <textarea
        id={name}
        name={name}
        required
        rows={rows}
        defaultValue={defaultValue}
        className={`w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm shadow-sm ${mono ? "font-mono" : ""}`}
      />
    </div>
  );
}

function FieldSelect({
  label,
  name,
  options,
  defaultValue,
  className,
  onChange
}: {
  label: string;
  name: string;
  options: string[];
  defaultValue?: string;
  className?: string;
  onChange?: (value: string) => void;
}) {
  return (
    <div className={className}>
      <label htmlFor={name} className="mb-2 block text-sm font-medium text-slate-700">
        {label}
      </label>
      <select
        id={name}
        name={name}
        defaultValue={defaultValue ?? options[0]}
        onChange={(event) => onChange?.(event.target.value)}
        className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm shadow-sm"
      >
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </div>
  );
}

function CheckField({
  name,
  label,
  defaultChecked
}: {
  name: string;
  label: string;
  defaultChecked?: boolean;
}) {
  return (
    <label className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 shadow-sm">
      <input type="checkbox" name={name} defaultChecked={defaultChecked} className="h-4 w-4 accent-[var(--brand-primary)]" />
      {label}
    </label>
  );
}

function getModuleTitle(category: string) {
  if (category === "ACCIDENT" || category === "NON_CONFORMANCE") return "Incident and non-conformance workflow";
  if (category === "OBSERVATION" || category === "CONVERSATION") return "Observation and conversation workflow";
  if (category === "ENVIRONMENT_AUDIT" || category === "SAFETY_INSPECTION") return "Audit and inspection workflow";
  if (category === "HSE_REPORT" || category === "TRAINING") return "Reporting and completion workflow";
  return "Module workflow";
}

function getModuleDescription(category: string) {
  if (category === "ACCIDENT" || category === "NON_CONFORMANCE") return "Capture incident type, accountability, loss potential, and management review like the super-user guide.";
  if (category === "OBSERVATION" || category === "CONVERSATION") return "Use observation-specific typing and follow-up fields to support proactive reporting.";
  if (category === "ENVIRONMENT_AUDIT" || category === "SAFETY_INSPECTION") return "Track audit type, serious findings, and accountable closure workflow in one place.";
  if (category === "HSE_REPORT" || category === "TRAINING") return "Document structured reports with ownership, findings, and review milestones.";
  return "Keep module-specific workflow fields aligned with the guide.";
}
