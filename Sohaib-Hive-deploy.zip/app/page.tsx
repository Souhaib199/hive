import Link from "next/link";
import {
  ArrowRight,
  BellRing,
  ChartColumnBig,
  FileSearch,
  ShieldCheck,
  Sparkles,
  TriangleAlert,
  Users,
  Waypoints
} from "lucide-react";

import { Logo } from "@/components/logo";
import { getSession } from "@/lib/auth";
import { getSettings } from "@/lib/store";

export default async function LandingPage() {
  const [session, settings] = await Promise.all([getSession(), getSettings()]);

  return (
    <main className="min-h-screen px-4 py-4 lg:px-6 lg:py-6">
      <div className="mx-auto flex min-h-[calc(100vh-2rem)] max-w-[1600px] flex-col overflow-hidden rounded-[40px] border border-white/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.9),rgba(237,245,240,0.88))] shadow-card backdrop-blur">
        <header className="flex flex-col gap-6 border-b border-white/70 px-6 py-6 lg:flex-row lg:items-center lg:justify-between lg:px-8">
          <Logo />
          <div className="flex flex-wrap items-center gap-3">
            <Link href="/login" className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700">
              Sign in
            </Link>
            <Link
              href={session ? "/dashboard" : "/login"}
              className="inline-flex items-center gap-2 rounded-2xl bg-clay px-4 py-3 text-sm font-semibold text-white shadow-[0_16px_34px_rgba(47,143,98,0.24)]"
            >
              {session ? "Open Platform" : "Launch Platform"}
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </header>

        <section className="relative overflow-hidden px-6 py-12 lg:px-8 lg:py-16">
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white to-transparent opacity-90" />
          <div className="absolute -left-24 top-10 h-64 w-64 rounded-full bg-[radial-gradient(circle,rgba(47,143,98,0.18),transparent_70%)]" />
          <div className="absolute right-0 top-0 h-[28rem] w-[28rem] rounded-full bg-[radial-gradient(circle,rgba(135,184,61,0.16),transparent_70%)]" />

          <div className="grid gap-10 lg:grid-cols-[1.15fr_0.85fr]">
            <div>
              <div className="flex flex-wrap items-center gap-3">
                <span className="rounded-full border border-emerald-100 bg-emerald-50 px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-teal">
                  Workforce Safety Intelligence
                </span>
                <span className="rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-slate-600">
                  HSE Platform
                </span>
              </div>

              <h1 className="mt-6 max-w-4xl text-5xl font-semibold uppercase leading-[0.95] tracking-[-0.05em] text-ink md:text-7xl">
                When Technology Enhances Workforce Safety.
              </h1>

              <p className="mt-6 max-w-2xl text-base leading-8 text-slate-600">
                {settings.brandName} helps organizations capture incidents, observations, conversations, audits, inspections, and HSE reports in one operational platform built to prevent harm before it happens.
              </p>

              <div className="mt-8 flex flex-wrap gap-3">
                <Link
                  href={session ? "/dashboard" : "/login"}
                  className="inline-flex items-center gap-2 rounded-2xl bg-ink px-5 py-3 text-sm font-semibold text-white shadow-[0_18px_34px_rgba(20,49,39,0.18)]"
                >
                  {session ? "Enter Dashboard" : "Login"}
                  <ArrowRight className="h-4 w-4" />
                </Link>
                <Link href="/search" className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700">
                  Explore Search Engine
                </Link>
              </div>
            </div>

            <div className="grid gap-4 self-start">
              <LandingPanel
                icon={<ShieldCheck className="h-5 w-5 text-emerald-700" />}
                title="Proactive case workflows"
                body="Move from isolated incident forms to connected case workflows covering accidents, observations, audits, and action closure."
              />
              <LandingPanel
                icon={<Waypoints className="h-5 w-5 text-emerald-700" />}
                title="Clear operational visibility"
                body="Track body-part exposure, safety pyramid signals, open actions, high-potential cases, and search-driven case intelligence."
              />
              <LandingPanel
                icon={<Sparkles className="h-5 w-5 text-emerald-700" />}
                title="Technology that predicts risk"
                body="Use analytics, notifications, and structured reporting to surface weak signals before they become serious events."
              />
            </div>
          </div>

          <div className="mt-14 grid gap-4 border-t border-white/70 pt-8 md:grid-cols-3">
            <LandingMetric value="1" label="Unified HSE platform for reporting, analytics, and follow-up" />
            <LandingMetric value="24/7" label="Operational visibility into cases, actions, and leadership review" />
            <LandingMetric value="360" label="Degree workforce safety view across people, process, and field exposure" />
          </div>
        </section>

        <section className="border-t border-white/70 px-6 py-12 lg:px-8">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-slate-500">Core Modules</p>
              <h2 className="mt-2 text-3xl font-semibold tracking-[-0.04em] text-ink">Organized around how HSE teams actually work</h2>
            </div>
            <p className="max-w-2xl text-sm leading-7 text-slate-500">
              From first report to management review and final closure, the platform is structured to support operational discipline, visibility, and prevention.
            </p>
          </div>

          <div className="mt-8 grid gap-4 xl:grid-cols-4">
            <ModuleCard
              title="Incident Management"
              body="Capture accidents, near misses, non-conformances, root causes, actions, and management remarks in one connected workflow."
              icon={<TriangleAlert className="h-5 w-5 text-emerald-700" />}
            />
            <ModuleCard
              title="Observations & Conversations"
              body="Record safe acts, unsafe acts, unsafe conditions, and field conversations before exposure turns into injury."
              icon={<Users className="h-5 w-5 text-emerald-700" />}
            />
            <ModuleCard
              title="Audits & Inspections"
              body="Track findings, accountable units, serious issues, follow-up actions, and closeout with better operational structure."
              icon={<ShieldCheck className="h-5 w-5 text-emerald-700" />}
            />
            <ModuleCard
              title="Search & Intelligence"
              body="Search by case, location, severity, body part, ownership, and workflow state through a dedicated HSE search engine."
              icon={<FileSearch className="h-5 w-5 text-emerald-700" />}
            />
          </div>
        </section>

        <section className="border-t border-white/70 px-6 py-12 lg:px-8">
          <div className="grid gap-6 xl:grid-cols-[1fr_1.05fr]">
            <div className="rounded-[34px] bg-[linear-gradient(135deg,#10271f,#17382d)] p-8 text-white shadow-card">
              <p className="text-xs uppercase tracking-[0.28em] text-emerald-200">Why It Matters</p>
              <h2 className="mt-3 max-w-2xl text-3xl font-semibold tracking-[-0.04em]">
                A platform built to move teams from reaction to prevention.
              </h2>
              <div className="mt-8 grid gap-4 sm:grid-cols-2">
                <DarkFeature
                  title="Predictive insights"
                  body="Surface weak signals through analytics, overdue actions, severity concentration, and field reporting patterns."
                  icon={<ChartColumnBig className="h-5 w-5 text-emerald-200" />}
                />
                <DarkFeature
                  title="Action accountability"
                  body="Tie every case to ownership, deadlines, workflow stage, and closure visibility."
                  icon={<Waypoints className="h-5 w-5 text-emerald-200" />}
                />
                <DarkFeature
                  title="Notification flow"
                  body="Keep supervisors, managers, and HSE leaders aligned on the items that need attention first."
                  icon={<BellRing className="h-5 w-5 text-emerald-200" />}
                />
                <DarkFeature
                  title="Safer workforce decisions"
                  body="Turn observations, injuries, audits, and reports into practical operational decisions."
                  icon={<Sparkles className="h-5 w-5 text-emerald-200" />}
                />
              </div>
            </div>

            <div className="rounded-[34px] border border-white/80 bg-white/82 p-8 shadow-card">
              <p className="text-xs uppercase tracking-[0.28em] text-slate-500">Platform Experience</p>
              <h2 className="mt-3 text-3xl font-semibold tracking-[-0.04em] text-ink">
                Designed for super users, supervisors, and leadership teams
              </h2>
              <div className="mt-6 space-y-4">
                {[
                  "Dedicated landing page, login flow, dashboard, search engine, and admin workspace",
                  "Separate operational modules for incidents, observations, audits, inspections, and reports",
                  "Interactive body-part mapping and safety-pyramid visibility for prevention-focused reviews",
                  "Configurable branding with platform logo and client/company logo together"
                ].map((item) => (
                  <div key={item} className="rounded-[22px] border border-slate-100 bg-slate-50/70 p-4 text-sm leading-7 text-slate-600">
                    {item}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <footer className="border-t border-white/70 px-6 py-10 lg:px-8">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-slate-500">Ready To Start</p>
              <h2 className="mt-2 text-3xl font-semibold tracking-[-0.04em] text-ink">
                Bring reporting, analytics, and prevention into one HSE workspace.
              </h2>
              <p className="mt-3 max-w-2xl text-sm leading-7 text-slate-500">
                Use the platform to capture what happens in the field, understand risk earlier, and support safer operational decisions across your workforce.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Link href="/login" className="rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700">
                Login
              </Link>
              <Link href={session ? "/dashboard" : "/login"} className="inline-flex items-center gap-2 rounded-2xl bg-clay px-5 py-3 text-sm font-semibold text-white shadow-[0_16px_34px_rgba(47,143,98,0.24)]">
                {session ? "Open Platform" : "Access Platform"}
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </footer>
      </div>
    </main>
  );
}

function LandingPanel({
  icon,
  title,
  body
}: {
  icon: React.ReactNode;
  title: string;
  body: string;
}) {
  return (
    <article className="rounded-[28px] border border-white/80 bg-white/80 p-5 shadow-sm">
      <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50">{icon}</div>
      <h2 className="mt-4 text-xl font-semibold text-ink">{title}</h2>
      <p className="mt-2 text-sm leading-7 text-slate-500">{body}</p>
    </article>
  );
}

function LandingMetric({ value, label }: { value: string; label: string }) {
  return (
    <div className="rounded-[24px] border border-white/80 bg-white/72 px-5 py-4 shadow-sm">
      <p className="text-3xl font-semibold tracking-[-0.04em] text-ink">{value}</p>
      <p className="mt-2 text-sm leading-6 text-slate-500">{label}</p>
    </div>
  );
}

function ModuleCard({
  title,
  body,
  icon
}: {
  title: string;
  body: string;
  icon: React.ReactNode;
}) {
  return (
    <article className="rounded-[28px] border border-white/80 bg-white/82 p-5 shadow-sm">
      <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50">{icon}</div>
      <h3 className="mt-4 text-xl font-semibold text-ink">{title}</h3>
      <p className="mt-2 text-sm leading-7 text-slate-500">{body}</p>
    </article>
  );
}

function DarkFeature({
  title,
  body,
  icon
}: {
  title: string;
  body: string;
  icon: React.ReactNode;
}) {
  return (
    <article className="rounded-[24px] border border-white/10 bg-white/5 p-4">
      <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10">{icon}</div>
      <h3 className="mt-4 text-lg font-semibold text-white">{title}</h3>
      <p className="mt-2 text-sm leading-7 text-slate-300">{body}</p>
    </article>
  );
}
