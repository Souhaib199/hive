import { NextResponse } from "next/server";

import { getSession } from "@/lib/auth";
import { createReport, listReports, listUsers } from "@/lib/store";
import { reportSchema } from "@/lib/validations";

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const [reports, users] = await Promise.all([listReports(), listUsers()]);

  return NextResponse.json({
    reports: reports
      .map((report) => ({
        ...report,
        author: users.find((user) => user.id === report.authorId) ?? null
      }))
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
  });
}

export async function POST(request: Request) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json();
  const parsed = reportSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid report payload.", issues: parsed.error.flatten() }, { status: 400 });
  }

  const report = await createReport({
    ...parsed.data,
    chartData: parsed.data.chartData,
    authorId: session.id
  });

  return NextResponse.json({ report }, { status: 201 });
}
