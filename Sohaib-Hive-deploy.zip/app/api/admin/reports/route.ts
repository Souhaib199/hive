import { NextResponse } from "next/server";

import { getSession } from "@/lib/auth";
import { getReportsForList } from "@/lib/queries";

export async function GET() {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const reports = await getReportsForList();

  return NextResponse.json({ reports });
}
