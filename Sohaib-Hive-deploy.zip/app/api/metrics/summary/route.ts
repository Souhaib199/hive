import { NextResponse } from "next/server";

import { getSession } from "@/lib/auth";
import { getDashboardMetrics } from "@/lib/queries";

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const metrics = await getDashboardMetrics();
  return NextResponse.json(metrics);
}
