import { redirect } from "next/navigation";

import { LoginForm } from "@/components/login-form";
import { Logo } from "@/components/logo";
import { getSession } from "@/lib/auth";
import { getSettings } from "@/lib/store";

export default async function LoginPage() {
  const session = await getSession();
  if (session) {
    redirect("/dashboard");
  }
  const settings = await getSettings();

  return (
    <main className="grid min-h-screen lg:grid-cols-[1.1fr_0.9fr]">
      <section className="hidden bg-ink p-10 text-white lg:flex lg:flex-col lg:justify-between">
        <Logo />
        <div>
          <p className="text-sm uppercase tracking-[0.34em] text-teal">{settings.productLabel}</p>
          <h1 className="mt-4 max-w-xl text-5xl font-semibold leading-tight">
            {settings.loginTitle}
          </h1>
          <p className="mt-4 max-w-lg text-slate-200">
            {settings.loginDescription}
          </p>
        </div>
        <p className="text-sm text-slate-300">Demo credentials are prefilled so you can explore the HSE dashboard quickly.</p>
      </section>

      <section className="flex items-center justify-center px-6 py-16">
        <div className="w-full max-w-md rounded-[32px] border border-white/80 bg-white/90 p-8 shadow-card backdrop-blur">
          <p className="text-sm uppercase tracking-[0.34em] text-teal">{settings.brandName}</p>
          <h2 className="mt-3 text-3xl font-semibold text-ink">Welcome back</h2>
          <p className="mt-2 text-sm text-slate-500">Use the seeded admin account to review HSE dashboards, entries, and the admin console.</p>
          <div className="mt-8">
            <LoginForm />
          </div>
        </div>
      </section>
    </main>
  );
}
