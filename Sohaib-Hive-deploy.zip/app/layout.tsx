import type { Metadata } from "next";
import { getSettings } from "@/lib/store";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sohaib Hive",
  description: "HSE reporting, observations, incidents, training, and audit platform"
};

export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const settings = await getSettings();

  return (
    <html lang="en">
      <body
        style={
          {
            ["--brand-primary" as string]: settings.primaryColor,
            ["--brand-accent" as string]: settings.accentColor,
            ["--brand-sidebar" as string]: settings.sidebarColor,
            ["--brand-surface" as string]: settings.surfaceTint
          } as React.CSSProperties
        }
      >
        {children}
      </body>
    </html>
  );
}
