import Link from "next/link";

import { ReportTable } from "@/components/report-table";
import { getReportsForList } from "@/lib/queries";
import { filterReports, getSearchFilters } from "@/lib/report-search";

export default async function ReportsPage({
  searchParams
}: {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
}) {
  const [reports, resolvedSearchParams] = await Promise.all([getReportsForList(), searchParams ?? Promise.resolve({})]);
  const filters = getSearchFilters(resolvedSearchParams);
  const filteredReports = filterReports(reports, filters);

  return (
    <div className="space-y-8">
      <section className="relative overflow-hidden rounded-[36px] border border-white/70 bg-[linear-gradient(135deg,rgba(255,255,255,0.95),rgba(237,245,240,0.92))] p-8 shadow-card">
        <div className="absolute -right-10 -top-10 h-36 w-36 rounded-full bg-[radial-gradient(circle,rgba(47,143,98,0.18),transparent_68%)]" />
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <p className="text-sm uppercase tracking-[0.34em] text-teal">HSE Register</p>
              <span className="rounded-full border border-emerald-100 bg-emerald-50 px-3 py-1 text-xs font-semibold uppercase tracking-[0.16em] text-teal">
                Operations Oversight
              </span>
            </div>
            <h1 className="mt-3 max-w-4xl text-4xl font-semibold leading-tight tracking-[-0.04em] text-ink">
              Track every observation, incident, audit, and training action with clearer operational control
            </h1>
            <p className="mt-3 max-w-3xl text-sm leading-7 text-slate-500">
              Browse published and draft HSE entries, review open actions, and keep oversight on severity, site exposure, and corrective ownership across the operation.
            </p>
          </div>
          <Link
            href="/reports/new"
            className="inline-flex items-center justify-center rounded-2xl bg-clay px-5 py-3 text-sm font-semibold text-white shadow-[0_16px_34px_rgba(47,143,98,0.24)]"
          >
            New HSE entry
          </Link>
        </div>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          <div className="rounded-[24px] border border-white bg-white/85 p-4 shadow-sm">
            <p className="text-xs uppercase tracking-[0.18em] text-slate-500">Records</p>
            <p className="mt-2 text-3xl font-semibold tracking-[-0.03em] text-ink">{filteredReports.length}</p>
          </div>
          <div className="rounded-[24px] border border-white bg-white/85 p-4 shadow-sm">
            <p className="text-xs uppercase tracking-[0.18em] text-slate-500">Open Actions</p>
            <p className="mt-2 text-3xl font-semibold tracking-[-0.03em] text-ink">
              {filteredReports.reduce((sum, report) => sum + report.actions.filter((action) => action.status !== "CLOSED").length, 0)}
            </p>
          </div>
          <div className="rounded-[24px] border border-white bg-white/85 p-4 shadow-sm">
            <p className="text-xs uppercase tracking-[0.18em] text-slate-500">High Potential</p>
            <p className="mt-2 text-3xl font-semibold tracking-[-0.03em] text-ink">
              {filteredReports.filter((report) => report.potentialSeverity === "HIGH" || report.potentialSeverity === "CRITICAL").length}
            </p>
          </div>
        </div>
      </section>

      <section className="rounded-[32px] border border-white/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.96),rgba(242,247,243,0.92))] p-6 shadow-card">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.28em] text-slate-500">Search Workspace</p>
            <h2 className="mt-2 text-2xl font-semibold tracking-[-0.03em] text-ink">Use the dedicated HSE search engine</h2>
            <p className="mt-2 text-sm text-slate-500">
              Run deeper queries, combine filters, and isolate injury trends or ownership gaps from one page.
            </p>
          </div>
          <Link href={`/search${buildSearchLink(resolvedSearchParams)}`} className="inline-flex items-center justify-center rounded-2xl bg-ink px-5 py-3 text-sm font-semibold text-white">
            Open Search Engine
          </Link>
        </div>
      </section>

      <ReportTable reports={filteredReports} />
    </div>
  );
}

function buildSearchLink(searchParams: Record<string, string | string[] | undefined>) {
  const query = new URLSearchParams();

  for (const [key, value] of Object.entries(searchParams)) {
    if (typeof value === "string" && value.length > 0) {
      query.set(key, value);
    }
  }

  const result = query.toString();
  return result ? `?${result}` : "";
}
