import Link from "next/link";
import { notFound } from "next/navigation";

import { ChartPreview } from "@/components/chart-preview";
import { getReportById } from "@/lib/queries";
import { formatCompact, formatDate } from "@/lib/utils";

export default async function ReportDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const report = await getReportById(id);

  if (!report) {
    notFound();
  }

  const chartData = Array.isArray(report.chartData)
    ? (report.chartData as Array<{ label: string; value: number }>)
    : JSON.parse(String(report.chartData)) as Array<{ label: string; value: number }>;

  return (
    <div className="space-y-8">
      <section className="rounded-[32px] border border-white/80 bg-white/80 p-8 shadow-card">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <p className="text-sm uppercase tracking-[0.34em] text-teal">{report.category}</p>
            <h1 className="mt-3 text-4xl font-semibold text-ink">{report.title}</h1>
            <p className="mt-4 max-w-3xl text-sm leading-7 text-slate-600">{report.description}</p>
            <div className="mt-5 flex flex-wrap gap-3">
              <span className="rounded-full bg-ink px-3 py-2 text-xs font-semibold uppercase tracking-[0.16em] text-white">
                {report.caseNumber}
              </span>
              <span className="rounded-full bg-emerald-50 px-3 py-2 text-xs font-semibold uppercase tracking-[0.16em] text-teal">
                {report.site}
              </span>
              <span className="rounded-full bg-slate-100 px-3 py-2 text-xs font-semibold uppercase tracking-[0.16em] text-slate-700">
                {report.department}
              </span>
              <span className="rounded-full bg-amber-50 px-3 py-2 text-xs font-semibold uppercase tracking-[0.16em] text-amber-700">
                Potential {report.potentialSeverity}
              </span>
            </div>
          </div>
          <div className="space-y-3">
            <div className="rounded-[28px] bg-slate-50 p-5">
              <p className="text-xs uppercase tracking-[0.22em] text-slate-500">KPI value</p>
              <p className="mt-2 text-3xl font-semibold text-ink">{formatCompact(report.metricValue)}</p>
              <p className="mt-2 text-sm text-slate-500">
                {report.periodLabel} · Updated {formatDate(report.updatedAt)}
              </p>
            </div>
            <Link
              href={`/reports/${report.id}/edit`}
              className="inline-flex rounded-2xl bg-clay px-5 py-3 text-sm font-semibold text-white"
            >
              Edit entry
            </Link>
          </div>
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-[1.25fr_0.95fr]">
        <ChartPreview data={chartData} />

        <div className="rounded-[28px] border border-white/80 bg-white/80 p-6 shadow-card">
          <p className="text-xs uppercase tracking-[0.22em] text-slate-500">Entry details</p>
            <div className="mt-5 grid gap-4 text-sm text-slate-600 sm:grid-cols-2">
            <div>
              <p className="font-semibold text-ink">Workflow stage</p>
              <p>{report.workflowStage}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Owner</p>
              <p>{report.author.name}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Reported by</p>
              <p>{report.reportedBy}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Focal person</p>
              <p>{report.focalPerson}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Responsible unit</p>
              <p>{report.responsibleUnit}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Site</p>
              <p>{report.site}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Department</p>
              <p>{report.department}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Status</p>
              <p>{report.status}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Visibility</p>
              <p>{report.visibility}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Period</p>
              <p>{report.periodLabel}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Incident type</p>
              <p>{report.incidentType}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Observation type</p>
              <p>{report.observationType}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Audit type</p>
              <p>{report.auditType}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Investigation start</p>
              <p>{report.investigationStartDate}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Resolution date</p>
              <p>{report.resolutionDate}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Change</p>
              <p>{report.metricDelta}%</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Actual severity</p>
              <p>{report.severity}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Potential severity</p>
              <p>{report.potentialSeverity}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Body part</p>
              <p>{report.bodyPart}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Risk type</p>
              <p>{report.riskType}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Work process</p>
              <p>{report.process}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">System involved</p>
              <p>{report.system}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Equipment involved</p>
              <p>{report.equipment}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Deviation</p>
              <p>{report.deviation}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Cause</p>
              <p>{report.cause}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Persons involved</p>
              <p>{report.personsInvolved}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Lost time days</p>
              <p>{report.lostTimeDays}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Training hours</p>
              <p>{report.trainingHours}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Audit score</p>
              <p>{report.auditScore}%</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Serious finding</p>
              <p>{report.seriousFinding ? "Yes" : "No"}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Non-conformance</p>
              <p>{report.hasNonConformance ? "Yes" : "No"}</p>
            </div>
          </div>
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-[28px] border border-white/80 bg-white/80 p-6 shadow-card">
          <p className="text-xs uppercase tracking-[0.22em] text-slate-500">Investigation</p>
          <div className="mt-5 space-y-5 text-sm text-slate-600">
            <div>
              <p className="font-semibold text-ink">Root cause</p>
              <p className="mt-1 leading-7">{report.rootCause}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Corrective action summary</p>
              <p className="mt-1 leading-7">{report.correctiveActionSummary}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Consequences / loss potential</p>
              <p className="mt-1 leading-7">{report.consequenceSummary}</p>
            </div>
            <div>
              <p className="font-semibold text-ink">Management remarks</p>
              <p className="mt-1 leading-7">{report.managementRemarks}</p>
            </div>
          </div>
        </div>

        <div className="rounded-[28px] border border-white/80 bg-white/80 p-6 shadow-card">
          <p className="text-xs uppercase tracking-[0.22em] text-slate-500">Action Tracker</p>
          <div className="mt-5 space-y-4">
            {report.actions.map((action, index) => (
              <div key={`${action.title}-${index}`} className="rounded-2xl border border-slate-100 p-4">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="font-semibold text-ink">{action.title}</p>
                    <p className="mt-1 text-sm text-slate-500">{action.owner}</p>
                  </div>
                  <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                    {action.status}
                  </span>
                </div>
                <p className="mt-3 text-sm text-slate-500">Due {action.dueDate}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
