import { notFound } from "next/navigation";

import { ReportForm } from "@/components/report-form";
import { getReportById } from "@/lib/queries";

export default async function EditReportPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const report = await getReportById(id);

  if (!report) {
    notFound();
  }

  return (
    <div className="space-y-8">
      <section className="rounded-[32px] border border-white/80 bg-white/80 p-8 shadow-card">
        <p className="text-sm uppercase tracking-[0.34em] text-teal">Edit HSE Entry</p>
        <h1 className="mt-3 text-4xl font-semibold text-ink">{report.title}</h1>
        <p className="mt-3 max-w-2xl text-sm text-slate-500">
          Update severity, actions, root cause, dates, ownership, and KPI values as the investigation progresses.
        </p>
      </section>

      <ReportForm mode="edit" initialData={report} />
    </div>
  );
}
