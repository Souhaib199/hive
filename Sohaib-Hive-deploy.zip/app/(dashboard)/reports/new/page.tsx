import { ReportForm } from "@/components/report-form";

export default function NewReportPage() {
  return (
    <div className="space-y-8">
      <section className="rounded-[32px] border border-white/80 bg-white/80 p-8 shadow-card">
        <p className="text-sm uppercase tracking-[0.34em] text-teal">Create HSE Entry</p>
        <h1 className="mt-3 text-4xl font-semibold text-ink">Log a new observation, accident, training item, or audit</h1>
        <p className="mt-3 max-w-2xl text-sm text-slate-500">
          Capture the event summary, KPI value, trend data, ownership, status, and visibility in a structured HSE workflow.
        </p>
      </section>

      <ReportForm />
    </div>
  );
}
