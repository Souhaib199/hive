import Link from "next/link";
import { ArrowRight, Activity, FolderKanban, Radar, ShieldCheck } from "lucide-react";

import { BodyHeatmap } from "@/components/body-heatmap";
import { MetricCard } from "@/components/metric-card";
import { PredictiveInsights } from "@/components/predictive-insights";
import { SafetyPyramid } from "@/components/safety-pyramid";
import { getDashboardMetrics } from "@/lib/queries";
import { getSettings } from "@/lib/store";
import { formatRelative } from "@/lib/utils";

export default async function DashboardPage() {
  const [metrics, settings] = await Promise.all([getDashboardMetrics(), getSettings()]);
  const allReports = metrics.latestReports;
  const highPotentialRatio =
    metrics.totals.reports === 0
      ? 0
      : Math.round(
          (metrics.latestReports.filter(
            (report) => report.potentialSeverity === "HIGH" || report.potentialSeverity === "CRITICAL"
          ).length /
            Math.max(metrics.latestReports.length, 1)) *
            100
        );
  const accidentSignal = metrics.totals.accidentCount > 0 ? "high" : metrics.totals.overdueActions > 0 ? "medium" : "low";

  const insights = [
    {
      title: "Fatality-potential exposure is clustering around open controls",
      detail: `${metrics.totals.overdueActions} overdue actions and ${metrics.totals.openActions} total open actions indicate higher escalation risk if corrective ownership stays delayed.`,
      tone: metrics.totals.overdueActions > 0 ? "high" : "low"
    },
    {
      title: "Leading indicators need reinforcement before lagging events rise",
      detail: `${metrics.totals.observationCount} observations and ${metrics.totals.conversationCount} conversations are currently offsetting ${metrics.totals.accidentCount} recorded accident cases.`,
      tone: accidentSignal
    },
    {
      title: "Recent high-potential activity needs targeted field review",
      detail: `${highPotentialRatio}% of the latest case feed carries high or critical potential severity. Prioritize site walkthroughs and supervisor conversations in those areas.`,
      tone: highPotentialRatio >= 40 ? "high" : highPotentialRatio >= 20 ? "medium" : "low"
    }
  ] as const;

  const notifications = [
    {
      title: "Overdue corrective actions require admin attention",
      detail: `${metrics.totals.overdueActions} actions are past due and should trigger escalation to the responsible owner and supervisor.`,
      tone: metrics.totals.overdueActions > 0 ? "high" : "low"
    },
    {
      title: "High-potential cases should be reviewed in the register",
      detail: `${metrics.latestReports.filter((report) => report.potentialSeverity === "HIGH" || report.potentialSeverity === "CRITICAL").length} of the latest reports are marked high or critical potential severity.`,
      tone: highPotentialRatio >= 30 ? "high" : "medium"
    },
    {
      title: "Training and conversations can reduce repeat exposure",
      detail: `${metrics.totals.trainingHours} training hours and ${metrics.totals.conversationCount} conversations have been logged. Reinforce the weak areas visible in the body-part map and case register.`,
      tone: "low"
    }
  ] as const;

  return (
    <div className="space-y-8">
      <section className="relative overflow-hidden rounded-[40px] bg-[linear-gradient(135deg,#0e211a_0%,#143127_55%,#1d4b35_100%)] px-8 py-10 text-white shadow-card">
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/70 to-transparent" />
        <div className="absolute -left-16 top-12 h-48 w-48 rounded-full bg-[radial-gradient(circle,rgba(135,184,61,0.24),transparent_68%)]" />
        <div className="absolute -right-10 bottom-0 h-56 w-56 rounded-full bg-[radial-gradient(circle,rgba(47,143,98,0.34),transparent_68%)]" />
        <div className="flex flex-wrap items-center gap-3">
          <p className="text-sm uppercase tracking-[0.34em] text-[#b6e1ad]">Sohaib Hive</p>
          <span className="rounded-full border border-white/10 bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.16em] text-slate-100">
            Executive HSE Intelligence
          </span>
        </div>
        <div className="mt-6 grid gap-8 lg:grid-cols-[1.25fr_0.9fr]">
          <div>
            <h1 className="max-w-3xl text-4xl font-semibold leading-tight tracking-[-0.04em] md:text-5xl">
              {settings.dashboardTitle}
            </h1>
            <p className="mt-4 max-w-2xl text-base leading-7 text-slate-200">{settings.dashboardDescription}</p>
            <div className="mt-8 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              {[
                { icon: ShieldCheck, label: "Editable Cases" },
                { icon: FolderKanban, label: "Action Ownership" },
                { icon: Activity, label: "Severity Tracking" },
                { icon: Radar, label: "Fatality Prevention" }
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="rounded-2xl border border-white/10 bg-white/8 px-4 py-4 text-sm text-slate-100 backdrop-blur">
                  <Icon className="mb-3 h-5 w-5 text-[#9fd69c]" />
                  <p className="font-medium">{label}</p>
                </div>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/reports/new" className="inline-flex items-center gap-2 rounded-2xl bg-white px-5 py-3 text-sm font-semibold text-ink shadow-[0_16px_34px_rgba(0,0,0,0.18)]">
                Create HSE Case
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link href="/reports" className="inline-flex items-center gap-2 rounded-2xl border border-white/15 bg-white/8 px-5 py-3 text-sm font-semibold text-white">
                Open Register
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
          <div className="rounded-[30px] border border-white/10 bg-white/8 p-6 backdrop-blur">
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="text-sm text-slate-200">Latest HSE activity</p>
                <p className="mt-1 text-xs uppercase tracking-[0.18em] text-slate-300">Live operational feed</p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/8 px-4 py-3 text-right">
                <p className="text-[11px] uppercase tracking-[0.16em] text-slate-300">Open actions</p>
                <p className="mt-1 text-2xl font-semibold">{metrics.totals.openActions}</p>
              </div>
            </div>
            <div className="mt-5 space-y-4">
              {allReports.map((report) => (
                <div key={report.id} className="rounded-2xl border border-white/8 bg-black/10 p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="font-semibold">{report.title}</p>
                      <p className="mt-1 text-xs uppercase tracking-[0.16em] text-slate-300">{report.site} · {report.category}</p>
                    </div>
                    <span className="rounded-full border border-white/10 bg-white/10 px-3 py-1 text-xs font-semibold">{report.potentialSeverity}</span>
                  </div>
                  <p className="mt-3 text-sm text-slate-200">{formatRelative(report.updatedAt)}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="grid gap-5 lg:grid-cols-4">
        <MetricCard title="Total HSE entries" value={String(metrics.totals.reports)} caption="Observations, incidents, audits, and training" />
        <MetricCard title="Open actions" value={String(metrics.totals.openActions)} caption="Corrective actions still in progress" />
        <MetricCard title="Overdue actions" value={String(metrics.totals.overdueActions)} caption="Items past due date needing escalation" />
        <MetricCard title="Training hours" value={String(metrics.totals.trainingHours)} caption="Recorded competency and refresh hours" />
      </section>

      <section className="grid gap-5 lg:grid-cols-3">
        <MetricCard title="Observations" value={String(metrics.totals.observationCount)} caption="Leading indicators captured" />
        <MetricCard title="Conversations" value={String(metrics.totals.conversationCount)} caption="Supervisor engagement in the field" />
        <MetricCard title="Accidents" value={String(metrics.totals.accidentCount)} caption="Lagging events needing control review" />
      </section>

      <section className="grid gap-6 xl:grid-cols-[0.95fr_1.25fr]">
        <div className="rounded-[32px] border border-white/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.95),rgba(240,246,242,0.92))] p-6 shadow-card">
          <p className="text-xs uppercase tracking-[0.28em] text-slate-500">HSE KPI Focus</p>
          <h2 className="mt-2 text-2xl font-semibold tracking-[-0.03em] text-ink">Leading and lagging indicators in one place</h2>
          <div className="mt-6 grid gap-4">
            {[
              "Leading indicators such as observations, conversations, and inspections",
              "Lagging indicators such as accidents, injury concentration, and findings",
              "Body-part visibility to guide PPE, ergonomic, and line-of-fire actions",
              "Safety pyramid framing to detect exposure before fatality potential grows"
            ].map((item) => (
              <div key={item} className="rounded-[22px] border border-white bg-white/80 p-4 text-sm leading-6 text-slate-600 shadow-sm">
                {item}
              </div>
            ))}
          </div>
        </div>

        <SafetyPyramid />
      </section>

      <PredictiveInsights insights={[...insights]} notifications={[...notifications]} />

      <BodyHeatmap />
    </div>
  );
}
