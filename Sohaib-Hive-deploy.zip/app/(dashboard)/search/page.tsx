import { SearchWorkspace } from "@/components/search-workspace";
import { getReportsForList } from "@/lib/queries";
import { filterReports, getSearchFilters, getSearchOptions } from "@/lib/report-search";

export default async function SearchPage({
  searchParams
}: {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
}) {
  const [reports, resolvedSearchParams] = await Promise.all([getReportsForList(), searchParams ?? Promise.resolve({})]);
  const filters = getSearchFilters(resolvedSearchParams);
  const filteredReports = filterReports(reports, filters);
  const options = getSearchOptions(reports);

  return <SearchWorkspace reports={filteredReports} filters={filters} options={options} />;
}
