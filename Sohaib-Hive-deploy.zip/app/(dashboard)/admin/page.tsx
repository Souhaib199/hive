import { redirect } from "next/navigation";

import { AdminConsole } from "@/components/admin-console";
import { getSession } from "@/lib/auth";
import { getAdminOverview } from "@/lib/queries";
import { getSettings } from "@/lib/store";

export default async function AdminPage() {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") {
    redirect(session ? "/dashboard" : "/login");
  }

  const [data, settings] = await Promise.all([getAdminOverview(), getSettings()]);

  return (
    <div className="space-y-8">
      <section className="relative overflow-hidden rounded-[36px] border border-white/70 bg-[linear-gradient(135deg,rgba(255,255,255,0.96),rgba(236,245,239,0.92))] p-8 shadow-card">
        <div className="absolute -right-12 -top-10 h-40 w-40 rounded-full bg-[radial-gradient(circle,rgba(47,143,98,0.16),transparent_68%)]" />
        <div className="flex flex-col gap-6 xl:flex-row xl:items-end xl:justify-between">
          <div>
            <p className="text-sm uppercase tracking-[0.34em] text-teal">HSE Admin</p>
            <h1 className="mt-3 max-w-4xl text-4xl font-semibold tracking-[-0.04em] text-ink">
              Administrative command layer for branding, governance, and platform control
            </h1>
            <p className="mt-3 max-w-3xl text-sm leading-7 text-slate-500">
              Tune the product identity, govern access, and review reporting quality from a more executive control surface.
            </p>
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-[22px] border border-white bg-white/85 px-5 py-4 shadow-sm">
              <p className="text-[11px] uppercase tracking-[0.18em] text-slate-500">Users</p>
              <p className="mt-2 text-3xl font-semibold tracking-[-0.03em] text-ink">{data.users.length}</p>
            </div>
            <div className="rounded-[22px] border border-white bg-white/85 px-5 py-4 shadow-sm">
              <p className="text-[11px] uppercase tracking-[0.18em] text-slate-500">Reports</p>
              <p className="mt-2 text-3xl font-semibold tracking-[-0.03em] text-ink">{data.reports.length}</p>
            </div>
            <div className="rounded-[22px] border border-white bg-white/85 px-5 py-4 shadow-sm">
              <p className="text-[11px] uppercase tracking-[0.18em] text-slate-500">High Potential</p>
              <p className="mt-2 text-3xl font-semibold tracking-[-0.03em] text-ink">
                {data.reports.filter((report) => report.potentialSeverity === "HIGH" || report.potentialSeverity === "CRITICAL").length}
              </p>
            </div>
          </div>
        </div>
      </section>

      <AdminConsole settings={settings} users={data.users} reports={data.reports} />
    </div>
  );
}
