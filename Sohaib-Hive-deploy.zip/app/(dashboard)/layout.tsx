import { redirect } from "next/navigation";
import Link from "next/link";
import { BellDot, Plus, ShieldAlert } from "lucide-react";

import { Sidebar } from "@/components/sidebar";
import { getSession } from "@/lib/auth";

export default async function DashboardLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  const session = await getSession();
  if (!session) {
    redirect("/login");
  }

  return (
    <div className="flex min-h-screen flex-col lg:flex-row">
      <Sidebar user={session} />
      <main className="flex-1 p-4 lg:p-6">
        <div className="mx-auto max-w-[1600px] space-y-6">
          <header className="relative overflow-hidden rounded-[34px] border border-white/70 bg-[linear-gradient(135deg,rgba(255,255,255,0.93),rgba(239,246,241,0.9))] px-6 py-5 shadow-card backdrop-blur lg:flex-row lg:items-center lg:justify-between">
            <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white to-transparent opacity-90" />
            <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-[radial-gradient(circle,rgba(47,143,98,0.18),transparent_68%)]" />
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-teal">Enterprise HSE Platform</p>
              <h1 className="mt-2 text-3xl font-semibold tracking-[-0.03em] text-ink">Sohaib Hive Control Room</h1>
              <p className="mt-2 text-sm text-slate-500">
                Manage critical HSE intelligence, actions, and investigations with a cleaner operational view.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <span className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-2 text-sm font-medium text-slate-700">
                <ShieldAlert className="h-4 w-4 text-teal" />
                Fatality risk monitored
              </span>
              <span className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-2 text-sm font-medium text-slate-700">
                <BellDot className="h-4 w-4 text-teal" />
                Live action oversight
              </span>
              <Link
                href="/reports/new"
                className="inline-flex items-center gap-2 rounded-2xl bg-clay px-4 py-2.5 text-sm font-semibold text-white shadow-[0_14px_32px_rgba(47,143,98,0.28)]"
              >
                <Plus className="h-4 w-4" />
                New Entry
              </Link>
            </div>
          </header>
          {children}
        </div>
      </main>
    </div>
  );
}
